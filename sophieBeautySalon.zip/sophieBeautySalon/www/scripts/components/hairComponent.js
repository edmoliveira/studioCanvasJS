class HairComponent extends RectangleComponent {
    constructor(page) {
        super(page);

        const self = this;

        self._i.color1 = null;
        self._i.color2 = null;
        self._i.color3 = null;

        self._i.front = new RectangleComponent();

        self._i.render = null;

        self._i.renderBack = () => { };
        self._i.renderFront = () => { };

        self.fillStyle = createStyleModel(typeFillStyle.BACK);
    }

    render(context, callback) {
        this._i.renderBack(context);
        if (callback != null) { callback(); }
        this._i.renderFront(context);
    }

    renderPath(context, callback) {
        context.beginPath();

        this._i.renderBack(context);
        if (callback != null) { callback(); }
        this._i.renderFront(context);

        context.closePath();
    }

    get front() {
        return this._i.front;
    }

    set front(v) {
        this._i.front = v;
    }

    get color1() {
        return this._i.color1;
    }

    set color1(v) {
        this._i.color1 = v;
    }

    get color2() {
        return this._i.color2;
    }

    set color2(v) {
        this._i.color2 = v;
    }

    get color3() {
        return this._i.color3;
    }

    set color3(v) {
        this._i.color3 = v;
    }
}

class OneHairComponent extends HairComponent {
    constructor(page) {
        super(page);

        const self = this;

        self._i.renderBack = (context) => {
            const loc = self.locationLineWidth();

            const x1 = loc.centerX;
            const y1 = loc.y1;

            const x2 = loc.centerX + loc.width * 0.2;
            const y2 = y1;

            const x3 = loc.centerX + loc.width * 0.7;
            const y3 = loc.y1 + loc.height * 0.3;

            const x4 = loc.centerX + loc.width * 0.4;
            const y4 = loc.y1 + loc.height * 0.95;

            const x5 = loc.centerX;
            const y5 = loc.y2 + loc.height * 0.05;

            const x6 = loc.centerX - loc.width * 0.4;
            const y6 = y4;

            const x7 = loc.centerX - loc.width * 0.7;
            const y7 = y3;

            const x8 = loc.centerX - loc.width * 0.2;
            const y8 = y2;

            context.beginPath();

            context.moveTo(x1, y1);
            context.bezierCurveTo(x2, y2, x3, y3, x4, y4);
            context.quadraticCurveTo(x5, y5, x6, y6);
            context.bezierCurveTo(x7, y7, x8, y8, x1, y1);

            self._i.renderFillStyle(context);
            self._i.renderStrokeStyle(context);

            context.closePath();
        };

        self._i.renderFront = (context) => {
            const loc = self.front.locationLineWidth();

            const x1 = loc.x1;
            const y1 = loc.y2;

            const x2 = x1;
            const y2 = loc.y1 - loc.height * 0.25;

            const x3 = loc.x2;
            const y3 = y2;

            const x4 = x3;
            const y4 = y1;

            const x5 = loc.centerX + loc.width * 0.3;
            const y5 = loc.y1 + loc.height * 0.4;

            const x6 = loc.centerX;
            const y6 = loc.y2;

            const x7 = loc.centerX - loc.width * 0.3;
            const y7 = y5;

            context.beginPath();

            context.moveTo(x1, y1);
            context.bezierCurveTo(x2, y2, x3, y3, x4, y4);
            context.quadraticCurveTo(x5, y5, x6, y6);
            context.quadraticCurveTo(x7, y7, x1, y1);

            self._i.renderFillStyle(context);
            self._i.renderStrokeStyle(context);

            context.closePath();
        };
    }

    setLocationSize(head) {
        this.width = head.width * 1.1;
        this.height = head.height * 0.95;
        this.x = head.x + head.width / 2 - this.width / 2;
        this.y = head.y - this.height * 0.15;

        const frontHair = this.front;

        frontHair.width = head.width * 0.6;
        frontHair.height = head.height * 0.15;
        frontHair.x = head.x + head.width / 2 - frontHair.width / 2;
        frontHair.y = head.y - this.height * 0.05;
    }
}

class TwoHairComponent extends HairComponent {
    constructor(page) {
        super(page);

        const self = this;

        self._i.renderBack = (context) => {
            const loc = self.locationLineWidth();

            const x1 = loc.centerX - loc.width * 0.35;
            const y1 = loc.y1 + loc.height * 0.2;

            const x2 = loc.centerX - loc.width * 0.3;
            const y2 = loc.y1 - loc.height * 0.06;

            const x3 = loc.centerX + loc.width * 0.3;
            const y3 = y2;

            const x4 = loc.centerX + loc.width * 0.35;
            const y4 = y1;

            const x5 = loc.centerX + loc.width * 0.42;
            const y5 = loc.y1 + loc.height * 0.4;

            const x6 = loc.centerX + loc.width * 0.6;
            const y6 = loc.y1 + loc.height * 0.8;

            const x7 = loc.centerX + loc.width * 0.45;
            const y7 = loc.y1 + loc.height;

            const x8 = loc.centerX;
            const y8 = loc.y1 + loc.height * 0.8;

            const x9 = loc.centerX - loc.width * 0.45;
            const y9 = y7;

            const x10 = loc.centerX - loc.width * 0.6;
            const y10 = y6;

            const x11 = loc.centerX - loc.width * 0.42;
            const y11 = y5;

            const x12 = loc.centerX - loc.width * 0.35;
            const y12 = y4;

            context.beginPath();

            context.moveTo(x1, y1);
            context.bezierCurveTo(x2, y2, x3, y3, x4, y4);
            context.bezierCurveTo(x5, y5, x6, y6, x7, y7);
            context.quadraticCurveTo(x8, y8, x9, y9);
            context.bezierCurveTo(x10, y10, x11, y11, x12, y12);

            self._i.renderFillStyle(context);
            self._i.renderStrokeStyle(context);

            context.closePath();
        };

        self._i.renderFront = (context) => {
            const loc = self.front.locationLineWidth();

            const x1 = loc.x1;
            const y1 = loc.y2;

            const x2 = x1;
            const y2 = loc.y1 - loc.height * 0.25;

            const x3 = loc.x2;
            const y3 = y2;

            const x4 = x3;
            const y4 = y1;

            const x5 = loc.centerX;
            const y5 = loc.y2;

            const x6 = loc.centerX - loc.width * 0.2;
            const y6 = loc.centerY + loc.height * 0.1;

            const x7 = loc.centerX - loc.width * 0.25;
            const y7 = loc.centerY + loc.height * 0.3;

            context.beginPath();

            context.moveTo(x1, y1);
            context.bezierCurveTo(x2, y2, x3, y3, x4, y4);
            context.quadraticCurveTo(x5, y5, x6, y6);
            context.quadraticCurveTo(x7, y7, x1, y1);

            self._i.renderFillStyle(context);
            self._i.renderStrokeStyle(context);

            context.closePath();
        };
    }

    setLocationSize(head) {
        this.width = head.width * 1.1;
        this.height = head.height * 0.95;
        this.x = head.x + head.width / 2 - this.width / 2;
        this.y = head.y - this.height * 0.15;

        const frontHair = this.front;

        frontHair.width = head.width * 0.8;
        frontHair.height = head.height * 0.2;
        frontHair.x = head.x + head.width / 2 - frontHair.width / 2;
        frontHair.y = head.y - this.height * 0.05;
    }
}

class ThreeHairComponent extends HairComponent {
    constructor(page) {
        super(page);

        const self = this;

        self._i.renderBack = (context) => {
            const loc = self.locationLineWidth();

            const x1 = loc.centerX;
            const y1 = loc.y1;

            const x2 = loc.x2;
            const y2 = loc.y1;

            const x3 = loc.centerX + loc.width * 0.55;
            const y3 = loc.y1 + loc.height * 0.4;

            const x4 = loc.centerX + loc.width * 0.45;
            const y4 = loc.y1 + loc.height * 0.6;

            const x5 = loc.centerX + loc.width * 0.55;
            const y5 = loc.y1 + loc.height * 0.8;

            const x6 = loc.centerX + loc.width * 0.35;
            const y6 = loc.y1 + loc.height * 1.05;

            const x7 = loc.centerX;
            const y7 = loc.y1 + loc.height;

            const x8 = loc.centerX - loc.width * 0.35;
            const y8 = y6;

            const x9 = loc.centerX - loc.width * 0.55;
            const y9 = y5;

            const x10 = loc.centerX - loc.width * 0.45;
            const y10 = y4;

            const x11 = loc.centerX - loc.width * 0.55;
            const y11 = y3;

            const x12 = loc.x1;
            const y12 = y2;

            context.beginPath();

            context.moveTo(x1, y1);
            context.bezierCurveTo(x2, y2, x3, y3, x4, y4);
            context.bezierCurveTo(x5, y5, x6, y6, x7, y7);
            context.bezierCurveTo(x8, y8, x9, y9, x10, y10);
            context.bezierCurveTo(x11, y11, x12, y12, x1, y1);

            self._i.renderFillStyle(context);
            self._i.renderStrokeStyle(context);

            context.closePath();
        };

        self._i.renderFront = (context) => {
            const loc = self.front.locationLineWidth();

            const x1 = loc.x1;
            const y1 = loc.y2;

            const x2 = x1;
            const y2 = loc.y1 - loc.height * 0.35;

            const x3 = loc.x2;
            const y3 = y2;

            const x4 = x3;
            const y4 = y1;

            const x5 = loc.centerX + loc.width * 0.35;
            const y5 = loc.y1 + loc.height * 0.6;

            const x6 = loc.centerX + loc.width * 0.2;
            const y6 = y5;

            const x7 = loc.centerX;
            const y7 = loc.y1 + loc.height * 0.8;

            const x8 = loc.centerX - loc.width * 0.2;
            const y8 = y6;

            const x9 = loc.centerX - loc.width * 0.35;
            const y9 = y5;

            context.beginPath();

            context.moveTo(x1, y1);
            context.bezierCurveTo(x2, y2, x3, y3, x4, y4);
            context.quadraticCurveTo(x5, y5, x6, y6);
            context.quadraticCurveTo(x7, y7, x8, y8);
            context.quadraticCurveTo(x9, y9, x1, y1);

            self._i.renderFillStyle(context);
            self._i.renderStrokeStyle(context);

            context.closePath();
        };
    }

    setLocationSize(head) {
        this.width = head.width * 1.1;
        this.height = head.height * 0.8;
        this.x = head.x + head.width / 2 - this.width / 2;
        this.y = head.y - this.height * 0.1;

        const frontHair = this.front;

        frontHair.width = head.width * 0.75;
        frontHair.height = head.height * 0.2;
        frontHair.x = head.x + head.width / 2 - frontHair.width / 2;
        frontHair.y = head.y;
    }
}

class FourHairComponent extends HairComponent {
    constructor(page) {
        super(page);

        const self = this;

        self._i.renderBack = (context) => {
            const loc = self.locationLineWidth();

            const x1 = loc.centerX - loc.width * 0.3;
            const y1 = loc.y1 + loc.height * 0.35;

            const x2 = x1;
            const y2 = loc.y1 - loc.height * 0.11;

            const x3 = loc.centerX + loc.width * 0.3;
            const y3 = y2;

            const x4 = x3;
            const y4 = y1;

            const x5 = loc.centerX - loc.width * 0.45;
            const y5 = loc.y2;

            const x6 = loc.centerX - loc.width * 0.6;
            const y6 = loc.y1 - loc.height * 0.1;

            const x7 = loc.centerX + loc.width * 0.6;
            const y7 = y6;

            const x8 = loc.centerX + loc.width * 0.45;
            const y8 = y5;

            context.beginPath();

            context.moveTo(x1, y1);
            context.bezierCurveTo(x2, y2, x3, y3, x4, y4);
            context.lineTo(x1, y1);

            context.fillStyle = self.color1;
            context.fill();

            context.closePath();

            context.beginPath();

            context.moveTo(x5, y5);
            context.bezierCurveTo(x6, y6, x7, y7, x8, y8);
            context.lineTo(x5, y5);

            const gradient = context.createLinearGradient(self.x, self.y, self.x + self.width, self.y);

            gradient.addColorStop(0.45, self.color2);
            gradient.addColorStop(0.5, self.color3);
            gradient.addColorStop(0.55, self.color2);

            context.fillStyle = gradient;
            context.fill();

            context.closePath();
        };

        self._i.renderFront = (context) => {
            const loc = self.front.locationLineWidth();

            const x1 = loc.x1;
            const y1 = loc.y2;

            const x2 = x1;
            const y2 = loc.y1 - loc.height * 0.4;

            const x3 = loc.x2;
            const y3 = y2;

            const x4 = x3;
            const y4 = y1;

            const x5 = loc.centerX + loc.width * 0.48;
            const y5 = y1;

            const x6 = x5;
            const y6 = loc.y1 + loc.height * 0.4;

            const x7 = loc.centerX - loc.width * 0.48;
            const y7 = y6;

            const x8 = x7;
            const y8 = y5;

            context.beginPath();

            context.moveTo(x1, y1);
            context.bezierCurveTo(x2, y2, x3, y3, x4, y4);
            context.lineTo(x5, y5);
            context.bezierCurveTo(x6, y6, x7, y7, x8, y8);

            const gradient = context.createLinearGradient(self.x, self.y, self.x + self.width, self.y);

            gradient.addColorStop(0.45, self.color2);
            gradient.addColorStop(0.5, self.color3);
            gradient.addColorStop(0.55, self.color2);

            context.fillStyle = gradient;
            context.fill();

            context.closePath();
        };
    }

    setLocationSize(head) {
        this.width = head.width * 0.88;
        this.height = head.height * 0.5;
        this.x = head.x + head.width / 2 - this.width / 2;
        this.y = head.y - this.height * 0.3;

        const frontHair = this.front;

        frontHair.width = head.width * 0.77;
        frontHair.height = head.height * 0.3;
        frontHair.x = head.x + head.width / 2 - frontHair.width / 2;
        frontHair.y = head.y;
    }
}