class EyeComponent extends RectangleComponent {
    constructor(page, isIcon) {
        super(page);

        const self = this;

        self.eyeballColor = '';
        self.lineEyeballColor = '';
        self.eyebrowColor = '';
        self.irisColor = '';
        self.pupilColor = '';

        self._i.locLeft = {
            x: 0
            , width: 0
        };

        self._i.locRight = {
            x: 0
            , width: 0
        }

        self._i.renderLeft = () => { };
        self._i.renderRight = () => { };

        self._i.render = (context) => {
            self._i.renderSide(context, self._i.locLeft);
            if (!isIcon) {
                self._i.renderSide(context, self._i.locRight, true);
            }
        };

        self._i.calculateIcon = () => {
            const loc = self._i.locationLineWidth();

            let width = loc.width * 0.8;
            let height = loc.height * 0.8;
            let x = loc.x1 + loc.width / 2 - width / 2;
            let y = loc.y1 + loc.height / 2 - height / 2;

            return { x: x, y: y, width: width, height: height };
        }
    }
}

class OneEyeComponent extends EyeComponent {
    constructor(page, isIcon) {
        super(page, isIcon);

        const self = this;

        self._i.renderSide = (context, loc, isRight) => {
            let x = loc.x;
            let y = self.y;
            let width = loc.width;
            let height = self.height;

            if (isIcon) {
                const locIcon = self._i.calculateIcon();

                x = locIcon.x;
                y = locIcon.y;
                width = locIcon.width;
                height = locIcon.height;
            }

            let centerX = x + width / 2;
            let centerY = y + height / 2;
            let radius = width / 2;

            let x1 = centerX - radius * 0.9;
            let y1 = y - radius * 0.2;

            let x2 = centerX - radius * 0.6;
            let y2 = y - radius * 0.7;

            let x3 = centerX + radius * 0.6;
            let y3 = y2;

            let x4= centerX + radius * 0.9;
            let y4 = y1;

            if (!isIcon) {
                context.beginPath();

                context.lineWidth = radius * 0.2;
                context.lineCap = 'round';

                context.moveTo(x1, y1);
                context.bezierCurveTo(x2, y2, x3, y3, x4, y4);

                context.strokeStyle = this.eyebrowColor;
                context.stroke();

                context.closePath();
            }

            context.beginPath();
            
            context.arc(centerX, centerY, radius, 0 * Math.PI, 2 * Math.PI);
            
            context.fillStyle = this.eyeballColor;
            context.fill();

            context.closePath();

            context.lineCap = null;

            context.beginPath();

            context.lineWidth = radius * 0.15;

            context.arc(centerX, centerY, radius * 1.05, 1 * Math.PI, 0 * Math.PI);

            context.strokeStyle = this.lineEyeballColor;
            context.stroke();

            context.closePath();

            context.beginPath();

            context.arc(centerX, centerY, radius * 0.5, 0 * Math.PI, 2 * Math.PI);

            context.fillStyle = this.irisColor;
            context.fill();

            context.closePath();

            context.beginPath();

            context.arc(centerX, centerY, radius * 0.15, 0 * Math.PI, 2 * Math.PI);

            context.fillStyle = this.pupilColor;
            context.fill();

            context.closePath();

            context.lineWidth = 1;
        };
    }

    setLocationSize(head) {
        this.width = head.width * 0.7;

        const eyeWidth = this.width * 0.25;

        this.height = eyeWidth;
        this.x = head.x + head.width / 2 - this.width / 2;
        this.y = head.y + head.height / 2.6 - this.height / 2;

        const left = this._i.locLeft;
        const right = this._i.locRight;        

        const wid = this.width / 2;

        left.width = eyeWidth;
        left.x = this.x + wid / 2 - eyeWidth / 2;

        right.width = eyeWidth;
        right.x = (this.x + wid) + wid / 2 - eyeWidth / 2;
    }
}

class TwoEyeComponent extends EyeComponent {
    constructor(page, isIcon) {
        super(page, isIcon);

        const self = this;

        self._i.renderSide = (context, loc, isRight) => {
            let x = loc.x;
            let y = self.y;
            let width = loc.width;
            let height = self.height;

            if (isIcon) {
                const locIcon = self._i.calculateIcon();

                x = locIcon.x;
                y = locIcon.y;
                width = locIcon.width;
                height = locIcon.height;
            }

            let centerX = x + width / 2;
            let centerY = y + height / 2;
            let radius = width / 2;

            let auxH = height * 0.1;

            let x1 = x;
            let y1 = y + height / 2;

            let x2 = centerX - width * 0.3;
            let y2 = y + auxH;

            let x3 = centerX + width * 0.3;
            let y3 = y2;

            let x4 = x + width;
            let y4 = y1;

            let x5 = x3;
            let y5 = y + height - auxH;

            let x6 = x2;
            let y6 = y5;

            context.beginPath();

            context.lineWidth = radius * 0.08;

            context.moveTo(x1, y1);
            context.bezierCurveTo(x2, y2, x3, y3, x4, y4);
            context.bezierCurveTo(x5, y5, x6, y6, x1, y1);

            context.fillStyle = this.eyeballColor;
            context.fill();

            context.strokeStyle = this.eyebrowColor;
            context.stroke();

            context.closePath();

            context.beginPath();

            context.arc(centerX, centerY, radius * 0.45, 0 * Math.PI, 2 * Math.PI);

            context.fillStyle = this.irisColor;
            context.fill();

            context.closePath();

            context.beginPath();

            context.arc(centerX, centerY, radius * 0.15, 0 * Math.PI, 2 * Math.PI);

            context.fillStyle = this.pupilColor;
            context.fill();

            context.closePath();

            if (!isIcon) {
                context.save();

                let eyebrowX = x;
                centerX = eyebrowX + width / 2;

                if (isRight) {
                    context.scale(-1, 1);

                    eyebrowX = -(x + width);
                    centerX = eyebrowX + width / 2;
                }

                x1 = eyebrowX + width;
                y1 = y + height * 0.15;

                x2 = centerX + width * 0.4;
                y2 = y;

                x3 = centerX;
                y3 = y - height * 0.1;

                x4 = centerX - width * 0.2;
                y4 = y3;

                x5 = centerX - width * 0.45;
                y5 = y4;

                x6 = eyebrowX;
                y6 = y + height * 0.05;

                context.beginPath();

                context.lineCap = 'round';

                context.lineWidth = radius * 0.2;

                context.moveTo(x1, y1);
                context.bezierCurveTo(x2, y2, x3, y3, x4, y4);
                context.quadraticCurveTo(x5, y5, x6, y6);

                context.strokeStyle = this.eyebrowColor;
                context.stroke();

                context.closePath();

                context.restore();
            }

            context.lineWidth = 1;
        };
    }

    setLocationSize(head) {
        this.width = head.width * 0.7;

        const eyeWidth = this.width * 0.25;

        this.height = eyeWidth;
        this.x = head.x + head.width / 2 - this.width / 2;
        this.y = head.y + head.height / 2.6 - this.height / 2;

        const left = this._i.locLeft;
        const right = this._i.locRight;

        const wid = this.width / 2;

        left.width = eyeWidth;
        left.x = this.x + wid / 2 - eyeWidth / 2;

        right.width = eyeWidth;
        right.x = (this.x + wid) + wid / 2 - eyeWidth / 2;
    }
}

class ThreeEyeComponent extends EyeComponent {
    constructor(page, isIcon) {
        super(page, isIcon);

        const self = this;

        self._i.renderSide = (context, loc, isRight) => {
            let x = loc.x;
            let y = self.y;
            let width = loc.width;
            let height = self.height;

            if (isIcon) {
                const locIcon = self._i.calculateIcon();

                x = locIcon.x;
                y = locIcon.y;
                width = locIcon.width;
                height = locIcon.height;
            }

            let centerX = x + width / 2;
            let centerY = y + height / 2;
            let radius = width / 2;

            if (!isIcon) {
                context.beginPath();

                context.lineWidth = radius * 0.2;
                context.lineCap = 'round';

                context.arc(centerX, y + radius * 0.5, radius, 1.2 * Math.PI, 1.8 * Math.PI);

                context.strokeStyle = this.eyebrowColor;
                context.stroke();

                context.closePath();
            }

            let auxW = loc.width * 0.1

            let x1 = centerX;
            let y1 = y;

            let x2 = x + width + auxW;
            let y2 = y1;

            let x3 = x2;
            let y3 = y + height;

            let x4 = x1;
            let y4 = y3;

            let x5 = x - auxW;
            let y5 = y3;

            let x6 = x5;
            let y6 = y2;

            context.beginPath();

            context.lineWidth = radius * 0.08;

            context.moveTo(x1, y1);
            context.bezierCurveTo(x2, y2, x3, y3, x4, y4);
            context.bezierCurveTo(x5, y5, x6, y6, x1, y1);

            context.fillStyle = this.eyeballColor;
            context.fill();

            context.strokeStyle = this.eyebrowColor;
            context.stroke();

            context.closePath();

            context.beginPath();

            context.arc(centerX, centerY, radius * 0.5, 0 * Math.PI, 2 * Math.PI);

            context.fillStyle = this.irisColor;
            context.fill();

            context.closePath();

            context.beginPath();

            context.arc(centerX, centerY, radius * 0.15, 0 * Math.PI, 2 * Math.PI);

            context.fillStyle = this.pupilColor;
            context.fill();

            context.closePath();
        };
    }

    setLocationSize(head) {
        this.width = head.width * 0.7;

        const eyeWidth = this.width * 0.2;

        this.height = eyeWidth * 1.2;
        this.x = head.x + head.width / 2 - this.width / 2;
        this.y = head.y + head.height / 2.6 - this.height / 2;

        const left = this._i.locLeft;
        const right = this._i.locRight;

        const wid = this.width / 2;

        left.width = eyeWidth;
        left.x = this.x + wid / 2 - eyeWidth / 2;

        right.width = eyeWidth;
        right.x = (this.x + wid) + wid / 2 - eyeWidth / 2;
    }
}

class FourEyeComponent extends EyeComponent {
    constructor(page, isIcon) {
        super(page, isIcon);

        const self = this;

        self._i.renderSide = (context, loc, isRight) => {
            let x = loc.x;
            let y = self.y;
            let width = loc.width;
            let height = self.height;

            if (isIcon) {
                const locIcon = self._i.calculateIcon();

                x = locIcon.x;
                y = locIcon.y;
                width = locIcon.width;
                height = locIcon.height;
            }

            let centerX = x + width / 2;
            let centerY = y + height / 2;
            let radius = width / 2;

            if (!isIcon) {

                context.beginPath();

                context.lineWidth = radius * 0.2;
                context.lineCap = 'round';

                if (isRight) {
                    context.arc(centerX, y + radius * 0.5, radius, 1.2 * Math.PI, 1.75 * Math.PI);
                }
                else {
                    context.arc(centerX, y + radius * 0.5, radius, 1.3 * Math.PI, 1.85 * Math.PI);
                }

                context.strokeStyle = this.eyebrowColor;
                context.stroke();

                context.closePath();
            }

            let auxW = width * 0.1

            let x1 = centerX;
            let y1 = y;

            let x2 = x + width + auxW;
            let y2 = y + height * 0.1;

            let x3 = x2;
            let y3 = y + height * 0.6;

            let x4 = x3;
            let y4 = y + height;

            let x5 = centerX;
            let y5 = y + height * 0.8;

            let x6 = x - auxW;
            let y6 = y4;

            let x7 = x6;
            let y7 = y3;

            let x8 = x7;
            let y8 = y2;

            context.save();

            context.beginPath();

            context.lineWidth = radius * 0.08;

            context.moveTo(x1, y1);
            context.bezierCurveTo(x2, y2, x3, y3, x4, y4);
            context.quadraticCurveTo(x5, y5, x6, y6);
            context.bezierCurveTo(x7, y7, x8, y8, x1, y1);

            context.fillStyle = this.eyeballColor;
            context.fill();

            context.strokeStyle = this.eyebrowColor;
            context.stroke();

            context.closePath();

            context.beginPath();

            context.moveTo(x1, y1);
            context.bezierCurveTo(x2, y2, x3, y3, x4, y4);
            context.quadraticCurveTo(x5, y5, x6, y6);
            context.bezierCurveTo(x7, y7, x8, y8, x1, y1);

            context.clip();

            context.closePath();

            context.beginPath();

            context.arc(centerX, centerY + radius * 0.4, radius * 0.7, 0 * Math.PI, 2 * Math.PI);

            context.fillStyle = this.irisColor;
            context.fill();

            context.closePath();

            context.beginPath();

            context.arc(centerX, centerY + radius * 0.4, radius * 0.2, 0 * Math.PI, 2 * Math.PI);

            context.fillStyle = this.pupilColor;
            context.fill();

            context.closePath();

            context.restore();
        };
    }

    setLocationSize(head) {
        this.width = head.width * 0.7;

        const eyeWidth = this.width * 0.2;

        this.height = eyeWidth * 1.2;
        this.x = head.x + head.width / 2 - this.width / 2;
        this.y = head.y + head.height / 2.6 - this.height / 2;

        const left = this._i.locLeft;
        const right = this._i.locRight;

        const wid = this.width / 2;

        left.width = eyeWidth;
        left.x = this.x + wid / 2 - eyeWidth / 2;

        right.width = eyeWidth;
        right.x = (this.x + wid) + wid / 2 - eyeWidth / 2;
    }
}