class EarComponent extends RectangleComponent {
    constructor(page) {
        super(page);

        const self = this;

        self.fillStyle = createStyleModel(typeFillStyle.BACK);

        self._i.locLeft = {
            x: 0
            , width: 0
        };

        self._i.locRight = {
            x: 0
            , width: 0
        }

        self._i.renderLeft = () => { };
        self._i.renderRight = () => { };

        self._i.render = (context) => {
            self._i.renderLeft(context);
            self._i.renderRight(context);
        };

        self._i.calculateIcon = () => {
            const loc = self._i.locationLineWidth();

            let width = loc.width * 0.8;
            let height = loc.height * 0.8;
            let x = loc.x1 + loc.width / 2 - width / 2;
            let y = loc.y1 + loc.height / 2 - height / 2;

            return { x: x, y: y, width: width, height: height };
        }
    }
}

class OneEarComponent extends EarComponent {
    constructor(page, isIcon) {
        super(page);

        const self = this;

        self._i.renderLeft = (context) => {
            if (isIcon) { return; }

            context.beginPath();

            let x = self._i.locLeft.x;
            let y = self.y;
            let width = self._i.locLeft.width;
            let height = self.height;
            let hAux = height * 0.15;

            let x1 = x + width;
            let y1 = y;

            let x2 = x;
            let y2 = y - hAux;

            let x3 = x2;
            let y3 = y + height + hAux;

            let x4 = x1;
            let y4 = y + height;

            context.moveTo(x1, y1);
            context.bezierCurveTo(x2, y2, x3, y3, x4, y4);
            context.lineTo(x1, y1);

            self._i.renderFillStyle(context);
            self._i.renderStrokeStyle(context);

            context.closePath();
        };
        self._i.renderRight = (context) => {
            context.beginPath();

            let x = self._i.locRight.x;
            let y = self.y;
            let width = self._i.locRight.width;
            let height = self.height;

            if (isIcon) {
                const loc = self._i.calculateIcon();

                x = loc.x;
                y = loc.y;
                width = loc.width;
                height = loc.height;
            }

            let hAux = height * 0.15;

            let x1 = x;
            let y1 = y;

            let x2 = x + width;
            let y2 = y - hAux;

            let x3 = x2;
            let y3 = y + height + hAux;

            let x4 = x1;
            let y4 = y + height;

            context.moveTo(x1, y1);
            context.bezierCurveTo(x2, y2, x3, y3, x4, y4);
            context.lineTo(x1, y1);

            self._i.renderFillStyle(context);
            self._i.renderStrokeStyle(context);

            context.closePath();
        };
    }

    setLocationSize(head) {
        this.width = head.width * (head._i.obj != null && head._i.obj.isFirstHead ? 0.65 : 0.7);
        this.height = head.height * 0.1;
        this.x = head.x + head.width / 2 - this.width / 2;
        this.y = head.y + head.height / 2.37 - this.height / 2;

        const earWidth = this.width * 0.15;

        const left = this._i.locLeft;
        const right = this._i.locRight;

        left.width = earWidth;
        left.x = this.x - earWidth;

        right.width = earWidth;
        right.x = this.x + this.width;
    }
}

class TwoEarComponent extends EarComponent {
    constructor(page, isIcon) {
        super(page);

        const self = this;

        self._i.renderLeft = (context) => {
            if (isIcon) { return; }

            context.beginPath();

            let x = self._i.locLeft.x;
            let y = self.y;
            let width = self._i.locLeft.width;
            let height = self.height;

            let x1 = x + width;
            let y1 = y;

            let x2 = x;
            let y2 = y - height * 0.15;

            let x3 = x2;
            let y3 = y + height * 0.7;

            let x4 = x1;
            let y4 = y + height;

            context.moveTo(x1, y1);
            context.bezierCurveTo(x2, y2, x3, y3, x4, y4);
            context.lineTo(x1, y1);

            self._i.renderFillStyle(context);
            self._i.renderStrokeStyle(context);

            context.closePath();
        };
        self._i.renderRight = (context) => {
            context.beginPath();

            let x = self._i.locRight.x;
            let y = self.y;
            let width = self._i.locRight.width;
            let height = self.height;

            if (isIcon) {
                const loc = self._i.calculateIcon();

                x = loc.x;
                y = loc.y;
                width = loc.width;
                height = loc.height;
            }

            let x1 = x;
            let y1 = y;

            let x2 = x + width;
            let y2 = y - height * 0.15;

            let x3 = x2;
            let y3 = y + height * 0.7;

            let x4 = x1;
            let y4 = y + height;

            context.moveTo(x1, y1);
            context.bezierCurveTo(x2, y2, x3, y3, x4, y4);
            context.lineTo(x1, y1);

            self._i.renderFillStyle(context);
            self._i.renderStrokeStyle(context);

            context.closePath();
        };
    }

    setLocationSize(head) {
        this.width = head.width * (head._i.obj != null && head._i.obj.isFirstHead ? 0.65 : 0.7);
        this.height = head.height * 0.1;
        this.x = head.x + head.width / 2 - this.width / 2;
        this.y = head.y + head.height / 2.37 - this.height / 2;

        const earWidth = this.width * 0.15;

        const left = this._i.locLeft;
        const right = this._i.locRight;

        left.width = earWidth;
        left.x = this.x - earWidth;

        right.width = earWidth;
        right.x = this.x + this.width;
    }
}

class ThreeEarComponent extends EarComponent {
    constructor(page, isIcon) {
        super(page);

        const self = this;

        self._i.renderLeft = (context) => {
            if (isIcon) { return; }

            context.beginPath();

            let x = self._i.locLeft.x;
            let y = self.y;
            let width = self._i.locLeft.width;
            let height = self.height;

            let x1 = x + width;
            let y1 = y;

            let x2 = x;
            let y2 = y - height * 0.2;

            let x3 = x + width * 0.25;
            let y3 = y + height * 0.3;

            let x4 = x + width * 0.35;
            let y4 = y + height * 0.6;

            let x5 = x + width * 0.5;
            let y5 = y + height;

            let x6 = x + width;
            let y6 = y + height;

            context.moveTo(x1, y1);
            context.bezierCurveTo(x2, y2, x3, y3, x4, y4);
            context.quadraticCurveTo(x5, y5, x6, y6);
            context.lineTo(x1, y1);

            self._i.renderFillStyle(context);
            self._i.renderStrokeStyle(context);

            context.closePath();
        };
        self._i.renderRight = (context) => {
            context.beginPath();

            let x = self._i.locRight.x;
            let y = self.y;
            let width = self._i.locRight.width;
            let height = self.height;

            if (isIcon) {
                const loc = self._i.calculateIcon();

                x = loc.x;
                y = loc.y;
                width = loc.width;
                height = loc.height;
            }

            let x1 = x;
            let y1 = y;

            let x2 = x + width;
            let y2 = y - height * 0.2;

            let x3 = (x + width) - width * 0.25;
            let y3 = y + height * 0.3;

            let x4 = (x + width) - width * 0.35;
            let y4 = y + height * 0.6;

            let x5 = (x + width) - width * 0.5;
            let y5 = y + height;

            let x6 = x ;
            let y6 = y + height;

            context.moveTo(x1, y1);
            context.bezierCurveTo(x2, y2, x3, y3, x4, y4);
            context.quadraticCurveTo(x5, y5, x6, y6);
            context.lineTo(x1, y1);

            self._i.renderFillStyle(context);
            self._i.renderStrokeStyle(context);

            context.closePath();
        };
    }

    setLocationSize(head) {
        this.width = head.width * (head._i.obj != null && head._i.obj.isFirstHead ? 0.65 : 0.7);
        this.height = head.height * 0.1;
        this.x = head.x + head.width / 2 - this.width / 2;
        this.y = head.y + head.height / 2.37 - this.height / 2;

        const earWidth = this.width * 0.12;

        const left = this._i.locLeft;
        const right = this._i.locRight;

        left.width = earWidth;
        left.x = this.x - earWidth;

        right.width = earWidth;
        right.x = this.x + this.width;
    }
}

class FourEarComponent extends EarComponent {
    constructor(page, isIcon) {
        super(page);

        const self = this;

        self._i.renderLeft = (context) => {
            if (isIcon) { return; }

            context.beginPath();

            let x = self._i.locLeft.x;
            let y = self.y;
            let width = self._i.locLeft.width;
            let height = self.height;

            let x1 = x + width;
            let y1 = y + height * 0.1;

            let x2 = x + width * 0.8;
            let y2 = y - height * 0.2;

            let x3 = x + width * 0.1;
            let y3 = y2;

            let x4 = x;
            let y4 = y1;

            let x5 = x + width * 0.2;
            let y5 = y + height * 1.3;

            let x6 = x + width;
            let y6 = y + height * 0.8;

            context.moveTo(x1, y1);
            context.bezierCurveTo(x2, y2, x3, y3, x4, y4);
            context.quadraticCurveTo(x5, y5, x6, y6);
            context.lineTo(x1, y1);

            self._i.renderFillStyle(context);
            self._i.renderStrokeStyle(context);

            context.closePath();
        };
        self._i.renderRight = (context) => {
            context.beginPath();

            let x = self._i.locRight.x;
            let y = self.y;
            let width = self._i.locRight.width;
            let height = self.height;

            if (isIcon) {
                const loc = self._i.calculateIcon();

                x = loc.x;
                y = loc.y + loc.height * 0.1;
                width = loc.width;
                height = loc.height;
            }

            let x1 = x;
            let y1 = y + height * 0.1;

            let x2 = x + width * 0.1;
            let y2 = y - height * 0.2;

            let x3 = x + width * 0.8;
            let y3 = y2;

            let x4 = x + width;
            let y4 = y1;

            let x5 = x + width * 0.8;
            let y5 = y + height * 1.3;

            let x6 = x;
            let y6 = y + height * 0.8;

            context.moveTo(x1, y1);
            context.bezierCurveTo(x2, y2, x3, y3, x4, y4);
            context.quadraticCurveTo(x5, y5, x6, y6);
            context.lineTo(x1, y1);

            self._i.renderFillStyle(context);
            self._i.renderStrokeStyle(context);

            context.closePath();
        };
    }

    setLocationSize(head) {
        this.width = head.width * (head._i.obj != null && head._i.obj.isFirstHead ? 0.65 : 0.7);
        this.height = head.height * 0.1;
        this.x = head.x + head.width / 2 - this.width / 2;
        this.y = head.y + head.height / 2.37 - this.height / 2;

        const earWidth = this.width * 0.12;

        const left = this._i.locLeft;
        const right = this._i.locRight;

        left.width = earWidth;
        left.x = this.x - earWidth;

        right.width = earWidth;
        right.x = this.x + this.width;
    }
}