class HeadComponent extends RectangleComponent {
    constructor(page, hasNeck) {
        super(page);

        const self = this;

        self._i.hasNeck = hasNeck;

        self.fillStyle = createStyleModel(typeFillStyle.BACK);

        const shadowRect = new RectangleComponent(self);

        shadowRect.fillStyle = createStyleModel(typeFillStyle.BACK);

        self._i.shadowRect = shadowRect;

        const createNeck = (context, x, y, width, height, lineWidth) => {
            const half = lineWidth > 0 ? lineWidth / 2 : 0;

            const rectWidth = width - half;
            const rectHeight = height - half;
            const rectX = (x + width / 2) - rectWidth / 2;
            const rectY = (y + height / 2) - rectHeight / 2;

            const centerX = rectX + rectWidth / 2;
            const centerY = rectY + rectHeight / 2;

            const x1 = centerX + rectWidth * 0.13;
            const y1 = rectY;

            const x2 = centerX + rectWidth * 0.15;
            const y2 = centerY - rectHeight * 0.1;

            const x3 = x + width;
            const y3 = centerY + rectHeight * 0.15;

            const x4 = x3;
            const y4 = rectY + rectHeight * 1.1;

            const x5 = x;
            const y5 = y4;

            const x6 = x5;
            const y6 = y3;

            const x7 = centerX - rectWidth * 0.15;
            const y7 = y2;

            const x8 = centerX - rectWidth * 0.13;
            const y8 = y1;

            context.save();

            context.beginPath();

            context.moveTo(x1, y1);
            context.lineTo(x2, y2);
            context.lineTo(x3, y3);
            context.bezierCurveTo(x4, y4, x5, y5, x6, y6);
            context.lineTo(x7, y7);
            context.lineTo(x8, y8);
            context.lineTo(x1, y1);

            self._i.renderFillStyle(context);
            self._i.renderStrokeStyle(context);

            context.closePath();

            context.clip();

            shadowRect.width = x2 - x7;
            shadowRect.height = height * 0.27;
            shadowRect.x = rectX + rectWidth / 2 - shadowRect.width / 2;
            shadowRect.y = rectY;

            shadowRect.renderPath(context);

            context.restore();
        };

        const createHead = this.hasNeck ?
            (context, x, y, width, height, lineWidth) => {
                const faceW = width * 0.75;
                const faceH = height * 0.75;
                const faceX = x + width / 2 - faceW / 2;
                const faceY = y;

                const neckW = width;
                const neckH = height - faceH * 0.9;
                const neckX = x;
                const neckY = y + height - neckH;

                createNeck(context, neckX, neckY, neckW, neckH, lineWidth);
                self._i.createFace(context, faceX, faceY, faceW, faceH, lineWidth);
            }
            :
            (context, x, y, width, height, lineWidth) => {
                self._i.createFace(context, x, y, width, height, lineWidth);
            };

        self._i.render = (context) => createHead(context, self.x, self.y, self.width, self.height, self.lineWidth);
    }

    get hasNeck() {
        return this._i.hasNeck;
    }

    get firstColor() {
        return this.fillStyle.color;
    }

    set firstColor(v) {
        this.fillStyle.color = v;
    }

    get secondColor() {
        return this._i.shadowRect.fillStyle.color;
    }

    set secondColor(v) {
        this._i.shadowRect.fillStyle.color = v;
    }

    render(context, callback) {
        this._i.render(context);
    }

    renderPath(context, callback) {
        context.beginPath();

        this._i.render(context);

        context.closePath();
    }

    setLocationSize(control) {
        const area = control.area;

        this.width = area * 0.1;
        this.height = this.width * 1.4;
        this.x = control.x + control.width / 2 - this.width / 2;
        this.y = control.y + control.height / 2 - this.height / 2.5;
    }
}

class OneHeadComponent extends HeadComponent {
    constructor(page, hasNeck = true) {
        super(page, hasNeck);

        const self = this;

        self.isFirstHead = true;

        self._i.createFace = (context, x, y, width, height, lineWidth) => {
            const half = lineWidth > 0 ? lineWidth / 2 : 0;

            const rectWidth = width - half;
            const rectHeight = height - half;
            const rectX = (x + width / 2) - rectWidth / 2;
            const rectY = (y + height / 2) - rectHeight / 2;

            const topRadius = rectWidth / 2;
            const topCenterX = rectX + topRadius;
            const topCenterY = rectY + topRadius;

            const halfH = rectHeight / 2;
            const centerY = rectY + halfH;

            const x1 = rectX + rectWidth;
            const y1 = topCenterY;

            const x2 = topCenterX + topRadius * 1.05;
            const y2 = centerY + halfH * 0.25;

            const x3 = topCenterX + topRadius * 0.3;
            const y3 = centerY + halfH * 1.05;

            const x4 = topCenterX;
            const y4 = rectY + rectHeight;

            const x5 = topCenterX - topRadius * 0.3;
            const y5 = y3;

            const x6 = topCenterX - topRadius * 1.05;
            const y6 = y2;

            const x7 = rectX;
            const y7 = y1;

            context.beginPath();

            context.arc(topCenterX, topCenterY, topRadius, 1 * Math.PI, 0 * Math.PI);

            context.moveTo(x1, y1);
            context.bezierCurveTo(x2, y2, x3, y3, x4, y4);
            context.bezierCurveTo(x5, y5, x6, y6, x7, y7);

            self._i.renderFillStyle(context);
            self._i.renderStrokeStyle(context);

            context.closePath();
        };
    }
}

class TwoHeadComponent extends HeadComponent {
    constructor(page, hasNeck = true) {
        super(page, hasNeck);

        const self = this;

        self._i.createFace = (context, x, y, width, height, lineWidth) => {
            const half = lineWidth > 0 ? lineWidth / 2 : 0;

            const rectWidth = width - half;
            const rectHeight = height - half;
            const rectX = x + width / 2 - rectWidth / 2;
            const rectY = y + height / 2 - rectHeight / 2;

            const centerX = rectX + rectWidth / 2;

            const x1 = centerX;
            const y1 = rectY;

            const x2 = rectX + rectWidth * 1.15;
            const y2 = y1;

            const x3 = x2;
            const y3 = rectY + rectHeight;

            const x4 = x1;
            const y4 = y3;

            const x5 = rectX - rectWidth * 0.15;
            const y5 = y3;

            const x6 = x5;
            const y6 = y2;

            context.beginPath();

            context.moveTo(x1, y1);
            context.bezierCurveTo(x2, y2, x3, y3, x4, y4);
            context.bezierCurveTo(x5, y5, x6, y6, x1, y1);

            self._i.renderFillStyle(context);
            self._i.renderStrokeStyle(context);

            context.closePath();
        };
    }
}

class ThreeHeadComponent extends HeadComponent {
    constructor(page, hasNeck = true) {
        super(page, hasNeck);

        const self = this;

        self._i.createFace = (context, x, y, width, height, lineWidth) => {
            const half = lineWidth > 0 ? lineWidth / 2 : 0;

            const rectWidth = width - half;
            const rectHeight = height - half;
            const rectX = (x + width / 2) - rectWidth / 2;
            const rectY = (y + height / 2) - rectHeight / 2;

            const centerX = rectX + rectWidth / 2;

            const x1 = centerX;
            const y1 = rectY;

            const x2 = centerX + rectWidth * 0.55;
            const y2 = y1;

            const x3 = x2;
            const y3 = rectY + rectHeight * 0.7;

            const x4 = centerX + rectWidth * 0.42;
            const y4 = rectY + rectHeight * 0.8;

            const x5 = centerX + rectWidth * 0.08;
            const y5 = rectY + rectHeight * 1.05;

            const x6 = centerX - rectWidth * 0.05;
            const y6 = y5;

            const x7 = centerX - rectWidth * 0.42;
            const y7 = y4;

            const x8 = centerX - rectWidth * 0.55;
            const y8 = y3;

            const x9 = x8;
            const y9 = y2;

            context.beginPath();

            context.moveTo(x1, y1);
            context.bezierCurveTo(x2, y2, x3, y3, x4, y4);
            context.bezierCurveTo(x5, y5, x6, y6, x7, y7);
            context.bezierCurveTo(x8, y8, x9, y9, x1, y1);

            self._i.renderFillStyle(context);
            self._i.renderStrokeStyle(context);

            context.closePath();
        };
    }
}

class FourHeadComponent extends HeadComponent {
    constructor(page, hasNeck = true) {
        super(page, hasNeck);

        const self = this;

        self._i.createFace = (context, x, y, width, height, lineWidth) => {
            const half = lineWidth > 0 ? lineWidth / 2 : 0;

            const rectWidth = width - half;
            const rectHeight = height - half;
            const rectX = (x + width / 2) - rectWidth / 2;
            const rectY = (y + height / 2) - rectHeight / 2;

            const topRadius = rectWidth / 2;
            const topCenterX = rectX + topRadius;
            const topCenterY = rectY + topRadius;

            const centeX = rectX + rectWidth / 2;

            const x1 = rectX + rectWidth;
            const y1 = topCenterY;

            const x2 = centeX + rectWidth * 0.6;
            const y2 = rectY + rectHeight * 1.2;

            const x3 = centeX - rectWidth * 0.6;
            const y3 = y2;

            const x4 = rectX;
            const y4 = y1;

            context.beginPath();

            context.arc(topCenterX, topCenterY, topRadius, 1 * Math.PI, 0 * Math.PI);

            context.moveTo(x1, y1);
            context.bezierCurveTo(x2, y2, x3, y3, x4, y4);

            self._i.renderFillStyle(context);
            self._i.renderStrokeStyle(context);

            context.closePath();
        };
    }
}

class CharaacterPartComponent extends RectangleComponent {
    constructor(page, hasNeck) {
        super(page);

        const self = this;

        self._i.render = (context) => {
            context.beginPath();

            const loc = self.locationLineWidth();

            context.moveTo(loc.x1, loc.y1);
            context.lineTo(loc.x2, loc.y1);
            context.lineTo(loc.x2, loc.y2);
            context.lineTo(loc.x1, loc.y2);
            context.lineTo(loc.x1, loc.y1);

            self._i.renderFillStyle(context);
            self._i.renderStrokeStyle(context);

            context.closePath();
        };
    }
}