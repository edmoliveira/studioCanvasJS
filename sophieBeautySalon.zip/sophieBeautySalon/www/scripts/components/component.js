"use strict";

class EventControl {
    _control = null;
    _page = null;
    _on = false;

    constructor(control, page) {
        this._control = control;
        this._page = page;
    }

    onTouchStart(fn) {
        oApp.oScene.onTouchStart((offsetX, offsetY) => {
            if (this._page.isOpen && this._control.checkPointIsInside(offsetX, offsetY)) {
                this._on = true;
                fn(this._control, offsetX, offsetY);
            }
        });
    }

    onTouchMove(fn) {
        oApp.oScene.onTouchMove((offsetX, offsetY) => {
            if (this._page.isOpen && this._control.checkPointIsInside(offsetX, offsetY)) {
                fn(this._control, offsetX, offsetY);
            }
        });
    }

    onTouchEnd(fn) {
        oApp.oScene.onTouchEnd((offsetX, offsetY) => {
            if (this._page.isOpen && this._on) {
                this._on = false;
                fn(this._control, offsetX, offsetY);
            }
        });
    }
}

class Control {
    _i = {}

    constructor() {
        this._i.x = 0;
        this._i.y = 0;
        this._i.lineWidth = 0;
    }

    get x() {
        return this._i.x;
    }

    set x(v) {
        this._i.x = v;
    }

    get y() {
        return this._i.y;
    }

    set y(v) {
        this._i.y = v;
    }

    get lineWidth() {
        return this._i.lineWidth;
    }

    set lineWidth(v) {
        this._i.lineWidth = v > 0 ? v : 0;
    }
}

class Component extends Control {
    constructor(page) {
        super();

        const self = this;

        self._i.eventControl = new EventControl(self, page);

        self._i.fillStyle = null;
        self._i.strokeStyle = null;
    }

    get fillStyle() {
        return this._i.fillStyle;
    }

    set fillStyle(v) {
        this._i.fillStyle = v;
    }

    get strokeStyle() {
        return this._i.strokeStyle;
    }

    set strokeStyle(v) {
        this._i.strokeStyle = v;
    }
}

class RectangleComponent extends Component {
    constructor(page) {
        super(page);
        const self = this;

        self._i.width = 0;
        self._i.height = 0;

        self._i.location = () => {
            return {
                x1: self.x
                , y1: self.y
                , x2: self.x + self.width
                , y2: self.y + self.height
                , centerX: self.x + self.width / 2
                , centerY: self.y + self.height / 2
                , width: self.width
                , height: self.height
            };
        }
        Object.freeze(self._i.location);

        self._i.locationLineWidth = () => {
            const half = self.lineWidth > 0 ? self.lineWidth / 2 : 0;

            const width = self.width - half;
            const height = self.height - half;
            const x = (self.x + self.width / 2) - width / 2;
            const y = (self.y + self.height / 2) - height / 2;

            return {
                x1: x
                , y1: y
                , x2: x + width
                , y2: y + height
                , centerX: x + width / 2
                , centerY: y + height / 2
                , width: width
                , height: height
            };
        };
        Object.freeze(self._i.locationLineWidth);

        self._i.renderFillStyle = (context) => {
            if (self.fillStyle != null) {
                context.fillStyle = self.fillStyle.getFill(context);
                context.fill();
            }
        };

        self._i.renderStrokeStyle = (context) => {
            if (self.strokeStyle != null) {
                const saveLine = context.lineWidth;

                context.lineWidth = self.lineWidth;

                context.strokeStyle = self.strokeStyle.getFill(context);
                context.stroke();

                context.lineWidth = saveLine;
            }
        };

        self._i.render = (context) => {
            const loc = self.locationLineWidth();       

            context.moveTo(loc.x1, loc.y1);
            context.lineTo(loc.x2, loc.y1);
            context.lineTo(loc.x2, loc.y2);
            context.lineTo(loc.x1, loc.y2);
            context.lineTo(loc.x1, loc.y1);

            self._i.renderFillStyle(context);
            self._i.renderStrokeStyle(context);
        };
    }

    get width() {
        return this._i.width;
    }

    set width(v) {
        this._i.width = v;
    }

    get height() {
        return this._i.height;
    }

    set height(v) {
        this._i.height = v;
    }

    get area() {
        return this._i.width * 2 + this._i.height * 2;
    }

    location() {
        return this._i.location();
    }

    locationLineWidth() {
        return this._i.locationLineWidth();
    }

    render(context) { this._i.render(context); }

    renderPath(context) {
        context.beginPath();

        this._i.render(context);

        context.closePath();
    }

    checkPointIsInside(x, y) {
        return oApp.oUtil.checkPointIsInsideRect(this.location(), x, y);
    }

    onTouchStart(fn) {
        this._i.eventControl.onTouchStart(fn);
    }

    onTouchMove(fn) {
        this._i.eventControl.onTouchMove(fn);
    }

    onTouchEnd(fn) {
        this._i.eventControl.onTouchEnd(fn);
    }
}

class RectangleArcComponent extends RectangleComponent {
    constructor(page) {
        super(page);
        const self = this;

        self._i.leftTopRadius = 0;
        self._i.rightTopRadius = 0;
        self._i.rightBottomRadius = 0;
        self._i.leftBottomRadius = 0;

        self._i.render = (context) => {
            const loc = self.locationLineWidth();

            context.moveTo(loc.x1, loc.y1 + self.leftTopRadius);
            context.arcTo(loc.x1, loc.y1, loc.x1 + self.leftTopRadius, loc.y1, self.leftTopRadius);
            context.lineTo(loc.x2 - self.rightTopRadius, loc.y1);
            context.arcTo(loc.x2, loc.y1, loc.x2, loc.y1 + self.rightTopRadius, self.rightTopRadius);
            context.lineTo(loc.x2, loc.y2 - self.rightBottomRadius);
            context.arcTo(loc.x2, loc.y2, loc.x2 - self.rightBottomRadius, loc.y2, self.rightBottomRadius);
            context.lineTo(loc.x1 + self.leftBottomRadius, loc.y2);
            context.arcTo(loc.x1, loc.y2, loc.x1, loc.y2 - self.leftBottomRadius, self.leftBottomRadius);
            context.lineTo(loc.x1, loc.y1 + self.leftTopRadius);

            self._i.renderFillStyle(context);
            self._i.renderStrokeStyle(context);
        };
    }

    get leftTopRadius() {
        return this._i.leftTopRadius;
    }

    set leftTopRadius(v) {
        this._i.leftTopRadius = v;
    }

    get rightTopRadius() {
        return this._i.rightTopRadius;
    }

    set rightTopRadius(v) {
        this._i.rightTopRadius = v;
    }

    get rightBottomRadius() {
        return this._i.rightBottomRadius;
    }

    set rightBottomRadius(v) {
        this._i.rightBottomRadius = v;
    }

    get leftBottomRadius() {
        return this._i.leftBottomRadius;
    }

    set leftBottomRadius(v) {
        this._i.leftBottomRadius = v;
    }    
}

class TextComponent extends Component {
    constructor(page) {
        super(page);
        const self = this;

        self._i.fontStyle = '';
        self._i.fontVariant = '';
        self._i.fontWeight = '';
        self._i.fontSize = '';
        self._i.fontFamily = '';
        self._i.text = '';

        self._i.renderFillStyle = (context) => {
            if (self.fillStyle != null) {
                context.fillStyle = self.fillStyle.getFill(context);
                context.fillText(self.text, self.x, self.y);
            }
        };

        self._i.renderStrokeStyle = (context) => {
            if (self.strokeStyle != null) {
                const saveLine = context.lineWidth;

                context.lineWidth = self.lineWidth;

                context.strokeStyle = self.strokeStyle.getFill(context);
                context.strokeText(self.text, self.x, self.y);

                context.lineWidth = saveLine;
            }
        };

        self._i.render = (context) => {            
            context.font = self.font;

            self._i.renderStrokeStyle(context);
            self._i.renderFillStyle(context);
        };
    }

    get font() {
        let font = '';

        if (this.fontStyle != null && this.fontStyle != '') { font += this.fontStyle + ' '; }
        if (this.fontVariant != null && this.fontVariant != '') { font += this.fontVariant + ' '; }
        if (this.fontWeight != null && this.fontWeight != '') { font += this.fontWeight + ' '; }
        if (this.fontSize != null && this.fontSize != '') { font += this.fontSize + 'px '; }
        if (this.fontFamily != null && this.fontFamily != '') { font += this.fontFamily; }

        return font;
    }

    get fontStyle() {
        return this._i.fontStyle;
    }

    set fontStyle(v) {
        this._i.fontStyle = v;
    }

    get fontVariant() {
        return this._i.fontVariant;
    }

    set fontVariant(v) {
        this._i.fontVariant = v;
    }

    get fontWeight() {
        return this._i.fontWeight;
    }

    set fontWeight(v) {
        this._i.fontWeight = v;
    }

    get fontSize() {
        return this._i.fontSize;
    }

    set fontSize(v) {
        this._i.fontSize = v;
    }

    get fontFamily() {
        return this._i.fontFamily;
    }

    set fontFamily(v) {
        this._i.fontFamily = v;
    }

    get text() {
        return this._i.text;
    }

    set text(v) {
        this._i.text = v;
    }

    render(context) { this._i.render(context); }

    renderPath(context) {
        context.beginPath();

        this._i.render(context);

        context.closePath();
    }
}

class CircleComponent {
    _i = {}

    constructor(page) {
        const self = this;

        self._i.eventControl = new EventControl(self, page);

        self._i.radius = 0;
        self._i.centerX = 0;
        self._i.centerY = 0;
        self._i.startAngle = 0;
        self._i.endAngle = 0;
        self._i.lineWidth = 0;
        self._i.fillStyle = null;
        self._i.strokeStyle = null;

        self._i.renderFillStyle = (context) => {
            if (self.fillStyle != null) {
                context.fillStyle = self.fillStyle.getFill(context);
                context.fill();
            }
        };

        self._i.renderStrokeStyle = (context) => {
            if (self.strokeStyle != null) {
                const saveLine = context.lineWidth;

                context.lineWidth = self.lineWidth;

                context.strokeStyle = self.strokeStyle.getFill(context);
                context.stroke();

                context.lineWidth = saveLine;
            }
        };

        self._i.render = (context) => {
            const half = self.lineWidth > 0 ? self.lineWidth / 2 : 0;
            const radius = self.radius - half;

            context.arc(self.centerX, self.centerY, radius, self.startAngle, self.endAngle);

            self._i.renderFillStyle(context);
            self._i.renderStrokeStyle(context);
        };
    }

    get radius() {
        return this._i.radius;
    }

    set radius(v) {
        this._i.radius = v;
    }

    get centerX() {
        return this._i.centerX;
    }

    set centerX(v) {
        this._i.centerX = v;
    }

    get centerY() {
        return this._i.centerY;
    }

    set centerY(v) {
        this._i.centerY = v;
    }

    get startAngle() {
        return this._i.startAngle;
    }

    set startAngle(v) {
        this._i.startAngle = v;
    }

    get endAngle() {
        return this._i.endAngle;
    }

    set endAngle(v) {
        this._i.endAngle = v;
    }

    get lineWidth() {
        return this._i.lineWidth;
    }

    set lineWidth(v) {
        this._i.lineWidth = v > 0 ? v : 0;
    }

    get fillStyle() {
        return this._i.fillStyle;
    }

    set fillStyle(v) {
        this._i.fillStyle = v;
    }

    get strokeStyle() {
        return this._i.strokeStyle;
    }

    set strokeStyle(v) {
        this._i.strokeStyle = v;
    }

    render(context) { this._i.render(context); }

    renderPath(context) {
        context.beginPath();

        this._i.render(context);

        context.closePath();
    }

    checkPointIsInside(x, y) {
        return oApp.oUtil.checkPointIsInsideCircle(this, x, y);
    }

    onTouchStart(fn) {
        this._i.eventControl.onTouchStart(fn);
    }

    onTouchMove(fn) {
        this._i.eventControl.onTouchMove(fn);
    }

    onTouchEnd(fn) {
        this._i.eventControl.onTouchEnd(fn);
    }
}