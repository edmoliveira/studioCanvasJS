const createEnumModel = (function (name, value) {
    return {
        name: name, value: value
    };
});

const enumFactory = (function (array) {
    let _selectors = '';
    let _array = array;

    class Enum {
        constructor() {

        }

        get selectors() {
            return _selectors;
        }

        getProperties(separeter) {
            if (separeter == null) {
                return _array.map(c => c.name);
            }
            else {
                return _array.map(c => c.name).reduce((result, name, index) => index > 0 ? result + separeter + name : result + name);
            }
        }

        getValues(separeter) {
            if (separeter == null) {
                return _array.map(c => c.value);
            }
            else {
                return _array.map(c => c.value).reduce((result, value, index) => index > 0 ? result + separeter + value : result + value);
            }
        }

        getName(value) {
            return _array.find(c => c.value === value).name;
        }

        getValue(name) {
            return _array.find(c => c.name === name).value;
        }
    }

    let oEnum = new Enum();

    for (let index = 0; index < _array.length; index++) {
        if (_selectors !== '') {
            _selectors += ',';
        }

        _selectors += '[' + _array[index].value + ']';

        (function (source, name, value) {
            Object.defineProperty(source, name, {
                get: function () {
                    return value;
                }
            });
        })(oEnum, _array[index].name, _array[index].value);
    }

    return oEnum;
});

const typeFillStyle = enumFactory([
    createEnumModel("BACK", 0)
    , createEnumModel("LINEAR", 1)
    , createEnumModel("RADIAL", 2)
]);