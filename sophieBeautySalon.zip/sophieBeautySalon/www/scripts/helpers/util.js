﻿function utilGame(oApp) {
    var self = this;

    self.getwindowSize = function () {
        var wi = window,
            d = document,
            e = d.documentElement,
            g = d.getElementsByTagName('body')[0],
            w = wi.innerWidth || e.clientWidth || g.clientWidth,
            h = wi.innerHeight || e.clientHeight || g.clientHeight;

        return { width: w, height: h };
    }

    self.timeDiff = function (time1, time2) {
        return parseInt((time1.getTime() - time2.getTime()) / 1000);
    }

    self.timeDiff_M = function (time1, time2) {
        return parseInt((time1.getTime() - time2.getTime()));
    }

    self.searchAngleCircle = function (centerX, centerY, radius, angle) {
        var angleX = centerX + (radius * Math.cos(angle * Math.PI / 180));
        var angleY = centerY + (radius * Math.sin(angle * Math.PI / 180));

        return {
            x: angleX, y: angleY
        };
    }

    self.getTextSize = function (text, fontSize, fontFamily, bold) {
        var obj = document.getElementById('measureTextLabel');

        obj.innerHTML = text;
        obj.style.fontSize = fontSize + 'px';
        obj.style.fontFamily = fontFamily;
        obj.style.fontWeight = bold;

        return { width: obj.offsetWidth, height: obj.offsetHeight };
    }

    self.movePointAtAngle = function (angle, speed) {
        var newAngle = angle * Math.PI / 180;

        var posX = (speed * Math.cos(newAngle));
        var posY = (speed * Math.sin(newAngle));

        return { x: posX, y: posY };
    }

    self.hexToRgb = function (hexcolor) {
        var r = parseInt(hexcolor.substr(1, 2), 16);
        var g = parseInt(hexcolor.substr(3, 2), 16);
        var b = parseInt(hexcolor.substr(5, 2), 16);

        return { r: r, g: g, b: b };
    }

    self.rgbToHsl = function (r, g, b) {
        var r1 = r / 255;
        var g1 = g / 255;
        var b1 = b / 255;

        var maxColor = Math.max(r1, g1, b1);
        var minColor = Math.min(r1, g1, b1);

        var L = (maxColor + minColor) / 2;
        var S = 0;
        var H = 0;

        if (maxColor != minColor) {

            if (L < 0.5) {
                S = (maxColor - minColor) / (maxColor + minColor);
            } else {
                S = (maxColor - minColor) / (2.0 - maxColor - minColor);
            }

            if (r1 == maxColor) {
                H = (g1 - b1) / (maxColor - minColor);
            } else if (g1 == maxColor) {
                H = 2.0 + (b1 - r1) / (maxColor - minColor);
            } else {
                H = 4.0 + (r1 - g1) / (maxColor - minColor);
            }
        }

        L = L * 100;
        S = S * 100;
        H = H * 60;

        if (H < 0) {
            H += 360;
        }

        var objHsl = {
            hue: Math.round(H)
            , saturation: Math.round(S)
            , lightness: Math.round(L)
        }

        return objHsl;
    }

    self.hslToRgb = function (h, s, l) {
        var r = 1;
        var g = 1;
        var b = 1;

        if (s === 0) {
            return { r: r, g: g, b: b };
        }

        h /= 360

        var q = l < 0.5 ? l * (1 + s) : l + s - l * s
        var p = 2 * l - q;

        r = Math.round(hueToRgb(p, q, h + 1 / 3) * 255);
        g = Math.round(hueToRgb(p, q, h) * 255);
        b = Math.round(hueToRgb(p, q, h - 1 / 3) * 255);

        return {
            r: r, g: g, b: b
        };
    }

    self.getValueScale = function (value) {
        let widthOrig = 640;
        let heightOrig = 360;

        let areaOrig = (widthOrig * 2) + (heightOrig * 2);
        let areaCurrent = (oApp.oGroupDrawingArea.size.width * 2) + (oApp.oGroupDrawingArea.size.height * 2);

        return (areaCurrent * value) / areaOrig;
    }

    self.getOneValueScale = function (value, origin, current) {
        return (current * value) / origin;
    }

    self.checkPointIsInsideRect = (loc, x, y) => {
        return (x >= loc.x1 && x <= loc.x2 && y >= loc.y1 && y <= loc.y2);
    }

    self.checkPointIsInsideCircle = (loc, x, y) => {
        var distanceSquared = (x - loc.centerX) * (x - loc.centerX) + (y - loc.centerY) * (y - loc.centerY);
        return distanceSquared <= Math.pow(loc.radius, 2);
    }

    self.concatUrl = function() {
        let url = '';

        if (arguments != null) {
            for (var index = 0; index < arguments.length; index++) {
                let arg = arguments[index];
                arg = arg.substr(arg.length - 1) === '/' ? arg.substr(0, arg.length - 1) : arg;
                arg = arg.substr(0, 1) === '/' ? (arg.length > 1 ? arg.substr(1) : '') : arg;

                url += index < arguments.length - 1 ? arg + '/' : arg;
            }
        }

        return url;
    }

    function hueToRgb(p, q, t) {
        if (t < 0) t += 1
        if (t > 1) t -= 1
        if (t < 1 / 6) return p + (q - p) * 6 * t
        if (t < 1 / 2) return q
        if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6

        return p
    }

    self.createTimer = function () {
        return new timerUtil(self);
    }
}

function timerUtil(parent) {
    var self = this;

    var _lastTime;
    var _currentDate;

    self.begin = function (seconds) {
        _lastTime = new Date();
    }

    self.current = function () {
        _currentDate = new Date();
    }

    self.end = function () {
        _lastTime = _currentDate;
    }

    self.getValuePosition = function (velocity) {
        var delta = parent.timeDiff_M(_currentDate, _lastTime) / 1000;

        return velocity * delta;
    }
}
/*
   var pattern = context.createPattern(this, "repeat");
    context.fillStyle = pattern;
    context.fill();
*/