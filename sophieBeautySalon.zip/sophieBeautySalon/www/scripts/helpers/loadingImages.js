class UrlImage {
    _i = {};

    constructor(url) {
        const self = this;

        self._i.wasLoading = false

        self._i.image = new Image();
        self._i.image.onload = function () { self._i.wasLoading = true; }
        self._i.image.src = url;
    }

    get image() {
        return this._i.image;
    }

    get wasLoading() {
        return this._i.wasLoading;
    }
}

class LoadingImages {
    _i = {};

    constructor() {
        const self = this;

        self._i.url = './images';
        self._i.home = null;
        self._i.musicHome = null;
        self._i.soundHome = null;
        self._i.character = null;

        self._i.headCharacter = null;
        self._i.hairCharacter = null;
        self._i.earCharacter = null;
        self._i.eyeCharacter = null;
        self._i.mouthCharacter = null;
    }

    get home() {
        return this._i.home;
    }

    loadHome() {
        const _back = new UrlImage(oApp.oUtil.concatUrl(this._i.url, 'home', 'background.jpg'));

        this._i.home = {
            get image() { return _back.image; }
            , get wasLoading() {
                return _back.wasLoading;
            }
        };

        return this._i.home;
    }

    get musicHome() {
        return this._i.musicHome;
    }

    loadMusicHome() {
        const _back = new UrlImage(oApp.oUtil.concatUrl(this._i.url, 'home', 'music.png'));

        this._i.musicHome = {
            get image() { return _back.image; }
            , get wasLoading() {
                return _back.wasLoading;
            }
        };

        return this._i.musicHome;
    }

    get soundHome() {
        return this._i.soundHome;
    }

    loadSoundHome() {
        const _back = new UrlImage(oApp.oUtil.concatUrl(this._i.url, 'home', 'sound.png'));

        this._i.soundHome = {
            get image() { return _back.image; }
            , get wasLoading() {
                return _back.wasLoading;
            }
        };

        return this._i.soundHome;
    }

    get character() {
        return this._i.character;
    }

    loadCharacter() {
        const _back = new UrlImage(oApp.oUtil.concatUrl(this._i.url, 'character', 'background.jpg'));

        this._i.character = {
            get image() { return _back.image; }
            , get wasLoading() {
                return _back.wasLoading;
            }
        };

        return this._i.character;
    }

    get headCharacter() {
        return this._i.headCharacter;
    }

    loadHeadCharacter() {
        const _back = new UrlImage(oApp.oUtil.concatUrl(this._i.url, 'character', 'head.png'));

        this._i.headCharacter = {
            get image() { return _back.image; }
            , get wasLoading() {
                return _back.wasLoading;
            }
        };

        return this._i.headCharacter;
    }

    get hairCharacter() {
        return this._i.hairCharacter;
    }

    loadHairCharacter() {
        const _back = new UrlImage(oApp.oUtil.concatUrl(this._i.url, 'character', 'hair.png'));

        this._i.hairCharacter = {
            get image() { return _back.image; }
            , get wasLoading() {
                return _back.wasLoading;
            }
        };

        return this._i.hairCharacter;
    }

    get earCharacter() {
        return this._i.earCharacter;
    }

    loadEarCharacter() {
        const _back = new UrlImage(oApp.oUtil.concatUrl(this._i.url, 'character', 'ear.png'));

        this._i.earCharacter = {
            get image() { return _back.image; }
            , get wasLoading() {
                return _back.wasLoading;
            }
        };

        return this._i.earCharacter;
    }

    get eyeCharacter() {
        return this._i.eyeCharacter;
    }

    loadEyeCharacter() {
        const _back = new UrlImage(oApp.oUtil.concatUrl(this._i.url, 'character', 'eye.png'));

        this._i.eyeCharacter = {
            get image() { return _back.image; }
            , get wasLoading() {
                return _back.wasLoading;
            }
        };

        return this._i.eyeCharacter;
    }

    get mouthCharacter() {
        return this._i.mouthCharacter;
    }

    loadMouthCharacter() {
        const _back = new UrlImage(oApp.oUtil.concatUrl(this._i.url, 'character', 'mouth.png'));

        this._i.mouthCharacter = {
            get image() { return _back.image; }
            , get wasLoading() {
                return _back.wasLoading;
            }
        };

        return this._i.mouthCharacter;
    }
}