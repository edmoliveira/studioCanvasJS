﻿(function () {
    "use strict";

    oApp.load(createGroupDrawingAreaModel(
        document.getElementById('wallpaperDA')
        , document.getElementById('backgroundDA')
        , document.getElementById('mainDA')
        , document.getElementById('screenDA')
    ));

    document.addEventListener( 'deviceready', onDeviceReady.bind( this ), false );

    function onDeviceReady() {
        document.addEventListener( 'pause', onPause.bind( this ), false );
        document.addEventListener( 'resume', onResume.bind( this ), false );        

        ready();
    };

    function onPause() {
        

    };

    function onResume() {
        
    };

    function ready() {
        oApp.setDeviceReady();
    }

    setTimeout(ready, 1500);
    //setTimeout(ready, 0);    
})();