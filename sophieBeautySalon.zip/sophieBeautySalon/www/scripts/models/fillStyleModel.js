const createStyleModel = (function (typeFill) {
    "use strict";

    let _backgroundColor;
    let _gradient;

    class StyleModel {
        constructor() {

        }

        getFill(context) {
            return itemType.getFill(context);
        }
    }

    class BackGroundModel extends StyleModel {
        constructor() {
            super();
        }

        get color() {
            return _backgroundColor;
        }

        set color(v) {
            _backgroundColor = v;
        }
    }

    class GradientModel extends StyleModel {
        constructor() {
            super();

            _gradient = {
                x0: 0
                , y0: 0
                , x1: 0
                , y1: 0
                , colorStopArray: []
            }
        }

        get x0() {
            return _gradient.x0;
        }

        get y0() {
            return _gradient.y0;
        }

        get x1() {
            return _gradient.x1;
        }

        get y1() {
            return _gradient.y1;
        }

        set x0(v) {
            _gradient.x0 = v;
        }

        set y0(v) {
            _gradient.y0 = v;
        }

        set x1(v) {
            _gradient.x1 = v;
        }

        set y1(v) {
            _gradient.y1 = v;
        }

        setCoordinates(x0, y0, x1, y1) {
            this.x0 = x0;
            this.y0 = y0;
            this.x1 = x1;
            this.y1 = y1;
        }

        addColorStop(offset, color) {
            _gradient.colorStopArray.push({ offset: offset, color: color });
        }

        cleanColorStop() {
            _gradient.colorStopArray = [];
        }
    }

    class GradientRadialModel extends StyleModel {
        constructor() {
            super();

            _gradient = {
                x0: 0
                , y0: 0
                , r0: 0
                , x1: 0
                , y1: 0
                , r1: 0
                , colorStopArray: []
            }
        }

        get x0() {
            return _gradient.x0;
        }

        get y0() {
            return _gradient.y0;
        }

        get r0() {
            return _gradient.r0;
        }

        get x1() {
            return _gradient.x1;
        }

        get y1() {
            return _gradient.y1;
        }

        get r1() {
            return _gradient.r1;
        }

        set x0(v) {
            _gradient.x0 = v;
        }

        set y0(v) {
            _gradient.y0 = v;
        }

        set r0(v) {
            _gradient.r0 = v;
        }

        set x1(v) {
            _gradient.x1 = v;
        }

        set y1(v) {
            _gradient.y1 = v;
        }

        set r1(v) {
            _gradient.r1 = v;
        }

        setCoordinates(x0, y0, r0, x1, y1, r1) {
            this.x0 = x0;
            this.y0 = y0;
            this.r0 = r0;
            this.x1 = x1;
            this.y1 = y1;
            this.r1 = r1;
        }

        addColorStop(offset, color) {
            _gradient.colorStopArray.push({ offset: offset, color: color });
        }

        cleanColorStop() {
            _gradient.colorStopArray = [];
        }
    }

    function getFillBackground() {
        return _backgroundColor;
    }

    function getFillGradient(context) {
        const gradient = context.createLinearGradient(_gradient.x0, _gradient.y0, _gradient.x1, _gradient.y1);

        _gradient.colorStopArray.forEach(item => {
            gradient.addColorStop(item.offset, item.color);
        });

        return gradient;
    }

    function getFillGradientRadial(context) {
        const gradient = context.createRadialGradient(_gradient.x0, _gradient.y0, _gradient.r0, _gradient.x1, _gradient.y1, _gradient.r1);

        _gradient.colorStopArray.forEach(item => {
            gradient.addColorStop(item.offset, item.color);
        });

        return gradient;
    }

    const types = [
        { type: typeFillStyle.BACK, getFill: getFillBackground, create: () => { return new BackGroundModel(); } }
        , { type: typeFillStyle.LINEAR, getFill: getFillGradient, create: () => { return new GradientModel(); } }
        , { type: typeFillStyle.RADIAL, getFill: getFillGradientRadial, create: () => { return new GradientRadialModel(); } }
    ];

    const itemType = types.find(item => item.type == typeFill);

    let obj = itemType.create();

    Object.freeze(obj);

    return obj;
});