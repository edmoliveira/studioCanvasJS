const createGroupDrawingAreaModel = ((wallDA, backElDA, mainElDA, screenElDA) => {
    "use strict";

    const createDrawingAreaModel = ((elDA) => {
        let _elDA = elDA;
        let _context;

        class DrawingAreaModel {
            constructor() {
                _context = _elDA.getContext("2d");
            }

            get width() {
                return _elDA.width;
            }

            get height() {
                return _elDA.height;
            }

            get element() {
                return _elDA;
            }

            getContext() {
                return _context;
            }

            clean() {
                _elDA.width = _elDA.width;
            }

            resize(width, height) {
                _elDA.width = width;
                _elDA.height = height;

                _elDA.style.width = width + 'px';
                _elDA.style.height = (height) + 'px';
            }
        }

        let obj = new DrawingAreaModel();

        Object.freeze(obj);

        return obj;
    });

    const _wallpaper = createDrawingAreaModel(wallDA);
    const _background = createDrawingAreaModel(backElDA);
    const _main = createDrawingAreaModel(mainElDA);
    const _screen = createDrawingAreaModel(screenElDA);
    const _size = {
        get width() {
            return _background.width;
        }
        , get height() {
            return _background.height;
        }
    }

    class GroupDrawingAreaModel {
        constructor() {

        }

        get wallpaper() {
            return _wallpaper;
        }

        get background() {
            return _background;
        }

        get main() {
            return _main;
        }

        get screen() {
            return _screen;
        }

        get size() {
            return _size;
        }

        resize(width, height) {
            this.wallpaper.resize(width, height);
            this.background.resize(width, height);
            this.main.resize(width, height);
            this.screen.resize(width, height);
        }
    }

    let obj = new GroupDrawingAreaModel();

    Object.freeze(obj);

    return obj;
});