"use strict";

class HomePageDesigner extends BasePage {
    constructor() {
        super();
    }

    initialize() {
        this._initializeBack(this.__protected.backControls);
        this._initializeMain(this.__protected.mainControls);
        this._initializeScreen(this.__protected.screenControls);
    }

    _initializeBack(controls) {
        const self = this;

        const backControl = new BackGroundHomeControl(self);

        controls.push((ctx) => {
            backControl.width = self.width * 0.97;
            backControl.height = self.height * 0.98;

            backControl.x = self.x + self.width / 2 - backControl.width / 2;
            backControl.y = self.y + self.height / 2 - backControl.height / 2;

            backControl.render(ctx);
        });
    }

    _initializeMain(controls) {

    }

    _initializeScreen(controls) {
        const self = this;

        const soundButton = new CircleButtonHomeControl(self);

        soundButton.onTouchStart(() => { });

        soundButton.onTouchEnd((source) => {
            if (source.isOn) {
                source.off();
            }
            else {
                source.on();
            }
        });

        soundButton.image = oApp.imageList.soundHome.image;

        controls.push((ctx) => {
            const area = self.width * 2 + self.height * 2;

            soundButton.radius = area * 0.018;
            soundButton.centerX = (self.x + self.width) - soundButton.radius * 1.5;
            soundButton.centerY = (self.y + self.height) - soundButton.radius * 1.5;

            soundButton.render(ctx);
        });

        const musicButton = new CircleButtonHomeControl(self);

        musicButton.onTouchStart(() => { });

        musicButton.onTouchEnd((source) => {
            if (source.isOn) {
                source.off();
            }
            else {
                source.on();
            }
        });

        musicButton.image = oApp.imageList.musicHome.image;

        controls.push((ctx) => {
            const area = self.width * 2 + self.height * 2;

            musicButton.radius = area * 0.018;
            musicButton.centerX = soundButton.centerX - soundButton.radius * 2.3;
            musicButton.centerY = (self.y + self.height) - musicButton.radius * 1.5;

            musicButton.render(ctx);
        });

        const playButton = new PlayButtonHomeControl(self);

        playButton.onTouchStart(() => { });

        playButton.onTouchEnd((source) => {
            oApp.oScene.oNavegation.homeToCharacter();
        });

        controls.push((ctx) => {
            const area = self.width * 2 + self.height * 2;

            playButton.width = area * 0.11;
            playButton.height = area * 0.037;
            playButton.x = self.x + self.width / 2 - playButton.width / 2;
            playButton.y = self.y + self.height / 2 - playButton.height / 2;

            playButton.render(ctx);
        });
    }
}

class HomePage extends HomePageDesigner {
    constructor() {
        super();

        this.__protected.createAnimation = async (oTimer) => {
            return await Promise.all([this._animationBack(oTimer), this._animationMain(oTimer), this._animationScreen(oTimer)]);
        }
    }

    async _animationBack(oTimer) {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                try {
                    resolve();
                }
                catch (e) {
                    reject(e);
                }
            }, 0);
        });
    }

    async _animationMain(oTimer) {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                try {
                    resolve();
                }
                catch(e) {
                    reject(e);
                }
            }, 0);
        });
    }

    async _animationScreen(oTimer) {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                try {
                    resolve();
                }
                catch (e) {
                    reject(e);
                }
            }, 0);
        });
    }
}

class BackGroundHomeControl extends Control {
    constructor(page) {
        super();
        const self = this;

        self._i.width = 0;
        self._i.height = 0;

        const border = new RectangleArcComponent(page);

        border.strokeStyle = createStyleModel(typeFillStyle.BACK);
        border.strokeStyle.color = '#FFFFFF';

        self._i.border = {
            render: (context) => {
                border.width = self.width;
                border.height = self.height;
                border.x = self.x;
                border.y = self.y;

                border.lineWidth = border.area * 0.004;

                const radius = border.area * 0.007;

                border.leftTopRadius = radius;
                border.rightTopRadius = radius;
                border.rightBottomRadius = radius;
                border.leftBottomRadius = radius;

                border.render(context);
            }
        };

        self._i.imageBack = {
            render: (context) => {
                const image = oApp.imageList.home.image;

                context.drawImage(image, 0, 0, image.width, image.height, self.x, self.y, self.width, self.height);
            }
        }

        const title = new TextComponent(page);

        title.fillStyle = createStyleModel(typeFillStyle.BACK);
        title.fillStyle.color = '#ee6996';

        title.strokeStyle = createStyleModel(typeFillStyle.BACK);
        title.strokeStyle.color = '#FFFFFF';

        title.fontFamily = 'seventies';
        title.text = "SOPHIE'S";

        self._i.title = {
            render: (context) => {
                const area = self.width * 2 + self.height * 2;

                title.lineWidth = area * 0.003;
                title.fontSize = area * 0.03;

                title.y = self.y + title.fontSize * 0.9;

                context.font = title.font;

                const textW = context.measureText(title.text).width;

                title.x = self.x + textW * 0.07;

                title.render(context);
            }
        }

        const subtitle = new TextComponent(page);

        subtitle.fillStyle = createStyleModel(typeFillStyle.BACK);
        subtitle.fillStyle.color = '#ee6996';

        subtitle.strokeStyle = createStyleModel(typeFillStyle.BACK);
        subtitle.strokeStyle.color = '#FFFFFF';

        subtitle.fontFamily = 'seventies';
        subtitle.text = "BEAUTY SALON";

        self._i.subtitle = {
            render: (context) => {
                const area = self.width * 2 + self.height * 2;

                subtitle.lineWidth = area * 0.003;
                subtitle.fontSize = area * 0.023;

                subtitle.y = title.y + subtitle.fontSize * 0.9;

                context.font = subtitle.font;

                const textW = context.measureText(subtitle.text).width;

                subtitle.x = (self.x + self.width) - textW * 1.1;

                subtitle.render(context);
            }
        }
    }

    get width() {
        return this._i.width;
    }

    set width(v) {
        this._i.width = v;
    }

    get height() {
        return this._i.height;
    }

    set height(v) {
        this._i.height = v;
    }

    render(context) {
        context.save();

        context.beginPath();

        this._i.border.render(context);
        context.clip();

        this._i.imageBack.render(context);        

        this._i.title.render(context);
        this._i.subtitle.render(context);

        context.closePath();

        context.restore();
    }
}

class CircleButtonHomeControl extends CircleComponent {
    constructor(page) {
        super(page);
        const self = this;

        self._i.image = null;
        self._i.on = true;

        const outerCircle = new CircleComponent(page);

        outerCircle.fillStyle = createStyleModel(typeFillStyle.RADIAL);

        outerCircle.strokeStyle = createStyleModel(typeFillStyle.BACK);
        outerCircle.strokeStyle.color = '#FFFFFF';

        self._i.render = (context) => {

            outerCircle.fillStyle.cleanColorStop();

            if (self._i.on) {
                outerCircle.fillStyle.addColorStop(0, '#e7ced6');
                outerCircle.fillStyle.addColorStop(0.9, '#ee6996');
            }
            else {
                outerCircle.fillStyle.addColorStop(0, '#FFFFFF');
                outerCircle.fillStyle.addColorStop(0.9, '#999999');
            }

            context.save();

            context.beginPath();

            context.shadowColor = '#333333';
            context.shadowBlur = 8;
            context.shadowOffsetX = 2;
            context.shadowOffsetY = 2;

            const radius = self.radius;

            outerCircle.lineWidth = radius * 0.075;
            outerCircle.radius = radius;
            outerCircle.centerX = self.centerX;
            outerCircle.centerY = self.centerY;
            outerCircle.startAngle = 0;
            outerCircle.endAngle = 2 * Math.PI;

            outerCircle.fillStyle.setCoordinates(self.centerX, self.centerY, radius * 0.1, self.centerX, self.centerY, radius);

            outerCircle.render(context);

            context.shadowColor = '#FFFFFF';
            context.shadowBlur = 2;
            context.shadowOffsetX = 2;
            context.shadowOffsetY = 2;

            const imageW = radius * 0.8;
            const imageH = imageW;
            const imageX = outerCircle.centerX - imageW / 2;
            const imageY = outerCircle.centerY - imageH / 2;

            if (!this._i.on) {
                context.filter = 'grayscale(100%)';
            }

            context.drawImage(self.image, 0, 0, self.image.width, self.image.height, imageX, imageY, imageW, imageH);            

            context.closePath();

            if (!this._i.on) {
                context.shadowColor = '#FFFFFF';
                context.shadowBlur = 2;
                context.shadowOffsetX = 1;
                context.shadowOffsetY = 2;

                const noSoundRadius = radius * 0.7;
                const point1 = oApp.oUtil.searchAngleCircle(self.centerX, self.centerY, noSoundRadius, 310);
                const point2 = oApp.oUtil.searchAngleCircle(self.centerX, self.centerY, noSoundRadius, 130);

                context.beginPath();

                context.lineWidth = outerCircle.lineWidth;

                context.moveTo(point1.x, point1.y);
                context.lineTo(point2.x, point2.y);

                context.strokeStyle = '#999999';
                context.stroke();

                context.closePath();

                context.lineWidth = 1;
            }

            context.restore();
        };
    }

    get image() {
        return this._i.image;
    }

    set image(v) {
        this._i.image = v;
    }

    get isOn() {
        return this._i.on;
    }

    on() {
        this._i.on = true;
    }

    off() {
        this._i.on = false;
    }
}

class PlayButtonHomeControl extends RectangleComponent {
    constructor(page) {
        super(page);
        const self = this;

        const rectFront = new RectangleArcComponent(page);

        rectFront.strokeStyle = createStyleModel(typeFillStyle.LINEAR);
        rectFront.strokeStyle.addColorStop(0, '#dddddd');
        rectFront.strokeStyle.addColorStop(0.5, '#FFFFFF');
        rectFront.strokeStyle.addColorStop(1, '#dddddd');

        rectFront.fillStyle = createStyleModel(typeFillStyle.LINEAR);
        rectFront.fillStyle.addColorStop(0, '#f3a5bf');
        rectFront.fillStyle.addColorStop(1, '#ef3674');

        const rectBack = new RectangleArcComponent(page);

        rectBack.fillStyle = createStyleModel(typeFillStyle.LINEAR);
        rectBack.fillStyle.addColorStop(0, '#dddddd');
        rectBack.fillStyle.addColorStop(0.5, '#FFFFFF');
        rectBack.fillStyle.addColorStop(1, '#dddddd');

        const title = new TextComponent(page);

        title.fillStyle = createStyleModel(typeFillStyle.BACK);
        title.fillStyle.color = '#ffffff';

        title.fontWeight = 'bold';
        title.fontFamily = "'Comic Sans MS'";
        title.text = "Play";

        self._i.render = (context) => {
            context.save();

            context.beginPath();

            context.globalAlpha = 0.9;

            const area = self.width * 2 + self.height * 2;

            const borderArc = area * 0.01;

            rectFront.leftTopRadius = borderArc;
            rectFront.rightTopRadius = borderArc;
            rectFront.rightBottomRadius = borderArc;
            rectFront.leftBottomRadius = borderArc;

            rectFront.lineWidth = area * 0.007;
            rectFront.x = self.x;
            rectFront.y = self.y;
            rectFront.width = self.width;
            rectFront.height = self.height * 0.85;

            rectBack.leftTopRadius = 0;
            rectBack.rightTopRadius = 0;
            rectBack.rightBottomRadius = borderArc;
            rectBack.leftBottomRadius = borderArc;

            rectBack.width = self.width * 1.01;
            rectBack.height = self.height * 0.15;
            rectBack.x = self.x + self.width / 2 - rectBack.width / 2;
            rectBack.y = rectFront.y + rectFront.height * 0.9;

            rectBack.fillStyle.setCoordinates(rectBack.x, rectBack.y, rectBack.x + rectBack.width, rectBack.y);

            rectBack.render(context);

            context.closePath();

            context.beginPath();

            rectFront.strokeStyle.setCoordinates(rectFront.x, rectFront.y, rectFront.x + rectFront.width, rectFront.y);
            rectFront.fillStyle.setCoordinates(rectFront.x, rectFront.y, rectFront.x, rectFront.y + rectFront.height);

            rectFront.render(context);

            context.closePath();

            context.globalAlpha = 1;

            context.beginPath();
            
            title.fontSize = area * 0.07;

            title.y = rectFront.y + rectFront.height / 2 + title.fontSize / 3.6;

            context.font = title.font;

            const textW = context.measureText(title.text).width;

            title.x = self.x + self.width / 2 - textW / 2;

            if (title.fontSize > 0) {
                title.render(context);
            }

            context.closePath();

            context.restore();
        };
    }
}