"use strict";

class CharacterPageDesigner extends BasePage {
    constructor() {
        super();
    }

    initialize() {
        const self = this;

        self._i.getMeasuresBackGround = () => {
            const width = self.width * 0.97;
            const height = self.height * 0.98;

            const x = self.x + self.width / 2 - width / 2;
            const y = self.y + self.height / 2 - height / 2;

            return { x: x, y: y, width: width, height: height };
        }

        self._initializeBack(self.__protected.backControls);
        self._initializeMain(self.__protected.mainControls);
        self._initializeScreen(self.__protected.screenControls);
    }

    _initializeBack(controls) {
        const self = this;

        const backControl = new BackGroundCharacterControl(self);

        controls.push((ctx) => {
            let measures = self._i.getMeasuresBackGround();

            backControl.width = measures.width;
            backControl.height = measures.height;

            backControl.x = measures.x;
            backControl.y = measures.y;

            backControl.render(ctx);
        });
    }

    _initializeMain(controls) {
        const self = this;        

        const character = {
            head: new CharacterPart()
            , hair: new CharacterPart()
            , ear: new CharacterPart()
            , eye: new CharacterPart()
            , mouth: new CharacterPart()
        };

        self._i.character = character;

        controls.push((context) => {
            const head = character.head;

            head.onSetColor(source => {
                source.firstColor = '#ffd0aa';
                source.secondColor = '#fcc496';
            });

            head.setLocationSize(self);
            
            if (character.hair.isNull) {
                head.render(context);
            }

            const hair = character.hair;

            hair.onSetColor(source => {
                source.color1 = '#4c2a0e';
                source.color2 = '#572e0e';
                source.color3 = '#84542c';

                source.fillStyle.color = '#994507';
            });

            hair.setLocationSize(head);

            const ear = character.ear;

            ear.onSetColor(source => {
                source.fillStyle.color = '#fec08e';
            });

            ear.setLocationSize(head);

            const eye = character.eye;

            eye.onSetColor(source => {
                source.eyeballColor = '#fbf3ec';
                source.lineEyeballColor = '#493C31';
                source.eyebrowColor = '#4c2a0e';
                source.irisColor = 'green';
                source.pupilColor = 'black';
            });

            eye.setLocationSize(head);

            hair.render(context, () => {
                ear.render(context);
                head.render(context);
                eye.render(context);
            });
        });
    }

    _initializeScreen(controls) {
        const self = this;

        const characterParts = [
            {
                onSetColor: (obj, backgroundColor, lineColor) => {
                    obj.firstColor = backgroundColor;
                    obj.secondColor = backgroundColor;

                    obj.strokeStyle = createStyleModel(typeFillStyle.BACK);
                    obj.strokeStyle.color = lineColor;
                }
                , iconArray: [
                    { optionId: 1, createIcon: () => new OneHeadComponent(self, false), createCharacter: () => new OneHeadComponent(self), obj: null }
                    , { optionId: 2, createIcon: () => new TwoHeadComponent(self, false), createCharacter: () => new TwoHeadComponent(self), obj: null }
                    , { optionId: 3, createIcon: () => new ThreeHeadComponent(self, false), createCharacter: () => new ThreeHeadComponent(self), obj: null }
                    , { optionId: 4, createIcon: () => new FourHeadComponent(self, false), createCharacter: () => new FourHeadComponent(self), obj: null }
                ]
            }
            , {
                onSetColor: (obj, backgroundColor, lineColor) => {
                    obj.color1 = backgroundColor;
                    obj.color2 = backgroundColor;
                    obj.color3 = backgroundColor;

                    obj.fillStyle = createStyleModel(typeFillStyle.BACK);
                    obj.fillStyle.color = backgroundColor;

                    obj.strokeStyle = createStyleModel(typeFillStyle.BACK);
                    obj.strokeStyle.color = lineColor;
                }
                , iconArray: [
                    { optionId: 1, createIcon: () => new OneHairComponent(self), createCharacter: () => new OneHairComponent(self), obj: null }
                    , { optionId: 2, createIcon: () => new TwoHairComponent(self), createCharacter: () => new TwoHairComponent(self), obj: null }
                    , { optionId: 3, createIcon: () => new ThreeHairComponent(self), createCharacter: () => new ThreeHairComponent(self), obj: null }
                    , { optionId: 4, createIcon: () => new FourHairComponent(self), createCharacter: () => new FourHairComponent(self), obj: null }
                ]
            }
            , {
                onSetColor: (obj, backgroundColor, lineColor) => {
                    obj.fillStyle = createStyleModel(typeFillStyle.BACK);
                    obj.fillStyle.color = backgroundColor;

                    obj.strokeStyle = createStyleModel(typeFillStyle.BACK);
                    obj.strokeStyle.color = lineColor;
                }
                , iconArray: [
                    { optionId: 1, createIcon: () => new OneEarComponent(self, true), createCharacter: () => new OneEarComponent(self), obj: null }
                    , { optionId: 2, createIcon: () => new TwoEarComponent(self, true), createCharacter: () => new TwoEarComponent(self), obj: null }
                    , { optionId: 3, createIcon: () => new ThreeEarComponent(self, true), createCharacter: () => new ThreeEarComponent(self), obj: null }
                    , { optionId: 4, createIcon: () => new FourEarComponent(self, true), createCharacter: () => new FourEarComponent(self), obj: null }
                ]
            }
            , {
                onSetColor: (obj, backgroundColor, lineColor) => {
                    obj.eyeballColor = backgroundColor;
                    obj.lineEyeballColor = lineColor;
                    obj.eyebrowColor = lineColor;
                    obj.irisColor = lineColor;
                    obj.pupilColor = backgroundColor;
                }
                , iconArray: [
                    { optionId: 1, createIcon: () => new OneEyeComponent(self, true), createCharacter: () => new OneEyeComponent(self), obj: null }
                    , { optionId: 2, createIcon: () => new TwoEyeComponent(self, true), createCharacter: () => new TwoEyeComponent(self), obj: null }
                    , { optionId: 3, createIcon: () => new ThreeEyeComponent(self, true), createCharacter: () => new ThreeEyeComponent(self), obj: null }
                    , { optionId: 4, createIcon: () => new FourEyeComponent(self, true), createCharacter: () => new FourEyeComponent(self), obj: null }
                ]
            }
            , {
                onSetColor: (obj, backgroundColor, lineColor) => {
                    obj.fillStyle = createStyleModel(typeFillStyle.BACK);
                    obj.fillStyle.color = backgroundColor;

                    obj.strokeStyle = createStyleModel(typeFillStyle.BACK);
                    obj.strokeStyle.color = lineColor;
                }
                , iconArray: [
                    { optionId: 1, createIcon: () => new CharaacterPartComponent(self), createCharacter: () => new CharaacterPartComponent(self), obj: null }
                    , { optionId: 2, createIcon: () => new CharaacterPartComponent(self), createCharacter: () => new CharaacterPartComponent(self), obj: null }
                    , { optionId: 3, createIcon: () => new CharaacterPartComponent(self), createCharacter: () => new CharaacterPartComponent(self), obj: null }
                    , { optionId: 4, createIcon: () => new CharaacterPartComponent(self), createCharacter: () => new CharaacterPartComponent(self), obj: null }
                ]
            }
        ];

        characterParts.forEach(item => {
            item.iconArray.forEach(icon => {
                icon.obj = icon.createIcon();

                item.onSetColor(icon.obj, '#cd4b66', '#EEEEEE');
            });
        });

        const buttonArray = [
            { image: oApp.imageList.headCharacter.image, icons: characterParts[0].iconArray, target: obj => self._i.character.head.setCharacter(obj), optionId: -1 }
            , { image: oApp.imageList.hairCharacter.image, icons: characterParts[1].iconArray, target: obj => self._i.character.hair.setCharacter(obj), optionId: -1 }
            , { image: oApp.imageList.earCharacter.image, icons: characterParts[2].iconArray, target: obj => self._i.character.ear.setCharacter(obj), optionId: -1 }
            , { image: oApp.imageList.eyeCharacter.image, icons: characterParts[3].iconArray, target: obj => self._i.character.eye.setCharacter(obj), optionId: -1 }
            , { image: oApp.imageList.mouthCharacter.image, icons: characterParts[4].iconArray, target: obj => self._i.character.mouth.setCharacter(obj), optionId: -1 }
        ];

        self._i.tabCount = buttonArray.length;

        const measures = (position) => {
            const areaW = self.width * 0.92;
            const areaX = self.x + self.width / 2 - areaW / 2;

            const boxAreaW = areaW / buttonArray.length;

            const boxW = boxAreaW * 0.95;
            const boxH = boxW;
            const boxX = (areaX + (boxAreaW * position)) + boxAreaW / 2 - boxW / 2;
            const boxY = self.y + self.height * 0.1;

            const rectW = self.width * 0.94;
            const rectH = self.height * 0.1;
            const rectX = ((self.x + self._i.indentationSizeChoice) + self.width * position) + self.width / 2 - rectW / 2;
            const rectY = self.y + self.height - rectH * 1.4;
            
            return {
                box: { x: boxX, y: boxY, width: boxW, height: boxH }
                , rect: { x: rectX, y: rectY, width: rectW, height: rectH}
            };
        };

        buttonArray.forEach((item, index) => {
            const circleButton = new IconButtonControl(self);

            circleButton.image = item.image;

            circleButton.onTouchStart(() => { });

            circleButton.onTouchEnd((source) => {
                self._i.onMoveTab(index);
            });

            item.icons.forEach(icon => {
                icon.obj.onTouchStart(() => { });

                icon.obj.onTouchEnd((source) => {
                    if (item.optionId !== icon.optionId) {
                        item.optionId = icon.optionId;
                        item.target(icon.createCharacter());
                    }
                });
            });

            const choiceRect = new RectangleComponent(self);

            choiceRect.fillStyle = createStyleModel(typeFillStyle.BACK);
            choiceRect.fillStyle.color = 'RGBA(255, 255, 255, 0.6)';

            controls.push((context) => {
                const measure = measures(index);
                const box = measure.box;
                const rect = measure.rect;

                context.save();

                let backMeas = self._i.getMeasuresBackGround();

                context.moveTo(backMeas.x, backMeas.y);
                context.lineTo(backMeas.x + backMeas.width, backMeas.y);
                context.lineTo(backMeas.x + backMeas.width, backMeas.y + backMeas.height);
                context.lineTo(backMeas.x, backMeas.y + backMeas.height);
                context.lineTo(backMeas.x, backMeas.y);

                context.clip();

                circleButton.radius = box.width / 2;
                circleButton.centerX = box.x + box.width / 2;
                circleButton.centerY = box.y + box.height / 2;

                circleButton.renderPath(context);

                choiceRect.x = rect.x;
                choiceRect.y = rect.y;
                choiceRect.width = rect.width;
                choiceRect.height = rect.height;

                choiceRect.renderPath(context);

                context.shadowColor = '#f25b8e';
                context.shadowBlur = 10;
                context.shadowOffsetX = 0;
                context.shadowOffsetY = 0;

                const iconBoxW = rect.width / item.icons.length;

                item.icons.forEach((icon, iconIndex) => {
                    const obj = icon.obj;

                    obj.width = iconBoxW * 0.5;
                    obj.height = rect.height * 0.88;
                    obj.x = (rect.x + iconBoxW * iconIndex) + iconBoxW / 2 - obj.width / 2;
                    obj.y = rect.y + rect.height / 2 - obj.height / 2;

                    obj.lineWidth = (obj.width * 2 + obj.height * 2) * 0.007;

                    obj.render(context);
                });

                context.restore();
            });
        });
    }
}

class CharacterPage extends CharacterPageDesigner {
    constructor() {
        super();
        const self = this;

        self._i.goalIndentationSizeChoice = 0;
        self._i.difIndentationSizeChoice = 0;
        self._i.indentationSizeChoice = 0;

        self.__protected.createAnimation = async (oTimer) => {
            return await Promise.all([self._animationBack(oTimer), self._animationMain(oTimer), self._animationScreen(oTimer)]);
        }

        self._i.onMoveTab = (index) => {
            self._i.goalIndentationSizeChoice = -(self.width * index);
            self._i.difIndentationSizeChoice = self._i.goalIndentationSizeChoice - self._i.indentationSizeChoice;
        }
    }

    async _animationBack(oTimer) {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                try {
                    resolve();
                }
                catch (e) {
                    reject(e);
                }
            }, 0);
        });
    }

    async _animationMain(oTimer) {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                try {
                    resolve();
                }
                catch (e) {
                    reject(e);
                }
            }, 0);
        });
    }

    async _animationScreen(oTimer) {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                try {
                    if (this._i.goalIndentationSizeChoice !== this._i.indentationSizeChoice) {
                        const originWidth = 360;
                        const currentWidth = Math.abs(this._i.indentationSizeChoice) + originWidth;
                        const porc = ((this._i.goalIndentationSizeChoice - this._i.indentationSizeChoice) / this._i.difIndentationSizeChoice);
                        const velocity = 350 + 650 * porc;

                        const speed = oTimer.getValuePosition(oApp.oUtil.getOneValueScale(velocity, originWidth, currentWidth));

                        if (this._i.goalIndentationSizeChoice > this._i.indentationSizeChoice) {
                            this._i.indentationSizeChoice += speed;

                            if (this._i.goalIndentationSizeChoice < this._i.indentationSizeChoice) {
                                this._i.indentationSizeChoice = this._i.goalIndentationSizeChoice;
                            }
                        }
                        else {
                            this._i.indentationSizeChoice -= speed;

                            if (this._i.goalIndentationSizeChoice > this._i.indentationSizeChoice) {
                                this._i.indentationSizeChoice = this._i.goalIndentationSizeChoice;
                            }
                        }
                    }

                    resolve();
                }
                catch (e) {
                    reject(e);
                }
            }, 0);
        });
    }
}

class BackGroundCharacterControl extends Control {
    constructor(page) {
        super();
        const self = this;

        self._i.width = 0;
        self._i.height = 0;

        const border = new RectangleArcComponent(page);

        border.strokeStyle = createStyleModel(typeFillStyle.BACK);
        border.strokeStyle.color = '#FFFFFF';

        self._i.border = {
            render: (context) => {
                border.width = self.width;
                border.height = self.height;
                border.x = self.x;
                border.y = self.y;

                border.lineWidth = border.area * 0.004;

                const radius = border.area * 0.007;

                border.leftTopRadius = radius;
                border.rightTopRadius = radius;
                border.rightBottomRadius = radius;
                border.leftBottomRadius = radius;

                border.render(context);
            }
        };

        self._i.imageBack = {
            render: (context) => {
                const image = oApp.imageList.character.image;

                context.drawImage(image, 0, 0, image.width, image.height, self.x, self.y, self.width, self.height);
            }
        }
    }

    get width() {
        return this._i.width;
    }

    set width(v) {
        this._i.width = v;
    }

    get height() {
        return this._i.height;
    }

    set height(v) {
        this._i.height = v;
    }

    render(context) {
        context.save();

        context.beginPath();

        this._i.border.render(context);
        context.clip();

        this._i.imageBack.render(context);   

        context.closePath();

        context.restore();
    }
}

class IconButtonControl extends CircleComponent {
    constructor(page) {
        super(page);
        const self = this;

        self._i.image = null;
        self._i.on = true;

        const outerCircle = new CircleComponent(page);

        outerCircle.fillStyle = createStyleModel(typeFillStyle.RADIAL);

        outerCircle.strokeStyle = createStyleModel(typeFillStyle.BACK);
        outerCircle.strokeStyle.color = '#aaaaaa';

        outerCircle.fillStyle.addColorStop(0, '#f2c6cb');
        outerCircle.fillStyle.addColorStop(0.9, '#ecaeb6');

        self._i.render = (context) => {
            context.save();

            context.beginPath();

            context.shadowColor = '#f25b8e';
            context.shadowBlur = 8;
            context.shadowOffsetX = 2;
            context.shadowOffsetY = 2;

            const radius = self.radius;

            outerCircle.lineWidth = radius * 0.075;
            outerCircle.radius = radius;
            outerCircle.centerX = self.centerX;
            outerCircle.centerY = self.centerY;
            outerCircle.startAngle = 0;
            outerCircle.endAngle = 2 * Math.PI;

            outerCircle.fillStyle.setCoordinates(self.centerX, self.centerY, radius * 0.1, self.centerX, self.centerY, radius);

            outerCircle.render(context);

            context.shadowColor = '#FFFFFF';
            context.shadowBlur = 2;
            context.shadowOffsetX = 2;
            context.shadowOffsetY = 2;

            const imageW = radius;
            const imageH = imageW;
            const imageX = outerCircle.centerX - imageW / 2;
            const imageY = outerCircle.centerY - imageH / 2;

            context.drawImage(self.image, 0, 0, self.image.width, self.image.height, imageX, imageY, imageW, imageH);

            context.closePath();

            context.restore();
        };
    }

    get image() {
        return this._i.image;
    }

    set image(v) {
        this._i.image = v;
    }
}

class CharacterPart {
    _i = {}

    constructor() {
        this._i.obj = {
            x: 0
            , y: 0
            , width: 0
            , height: 0
            , render: () => { }
            , setLocationSize: () => { }
            , fillStyle: createStyleModel(typeFillStyle.BACK)
            , strokeStyle: createStyleModel(typeFillStyle.BACK)
            , isNull: true
        };
    }

    onSetColor(callback) {
        if (!this._i.isNull) {
            callback(this._i.obj);
        }
    }

    setCharacter(obj) {
        this._i.isNull = false;
        this._i.obj = obj;
    }

    get isNull() {
        return this._i.obj.isNull;
    }

    get x() {
        return this._i.obj.x;
    }

    set x(v) {
        this._i.obj.x = v;
    }

    get y() {
        return this._i.obj.y;
    }

    set y(v) {
        this._i.obj.y = v;
    }

    get width() {
        return this._i.obj.width;
    }

    set width(v) {
        this._i.obj.width = v;
    }

    get height() {
        return this._i.obj.height;
    }

    set height(v) {
        this._i.obj.height = v;
    }

    get fillStyle() {
        return this._i.obj.fillStyle;
    }

    set fillStyle(v) {
        this._i.obj.fillStyle = v;
    }

    get strokeStyle() {
        return this._i.obj.strokeStyle;
    }

    set strokeStyle(v) {
        this._i.obj.strokeStyle = v;
    }

    render(context, callback) { this._i.obj.render(context, callback); }

    setLocationSize(control) { this._i.obj.setLocationSize(control);}
}