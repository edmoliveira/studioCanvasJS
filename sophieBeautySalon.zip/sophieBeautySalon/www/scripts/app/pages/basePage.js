"use strict";

class BasePage extends RectangleComponent {
    __protected = {};
    
    constructor() {
        super();

        this.__protected.backControls = [];
        this.__protected.mainControls = [];
        this.__protected.screenControls = [];

        this.__protected.createAnimation = null;

        this._i.isOpen = false;
    }

    get isOpen() {
        return this._i.isOpen;
    }

    set isOpen(v) {
        this._i.isOpen = v;
    }

    resize(width, height) {
        this.width = width;
        this.height = height;
    }

    async animation(oTimer) {
        const self = this;

        return new Promise((resolve, reject) => {
            self.__protected.createAnimation(oTimer)
                .then(() => {
                    const promises = [
                        self._draw(oApp.oGroupDrawingArea.background, self.__protected.backControls)
                        , self._draw(oApp.oGroupDrawingArea.main, self.__protected.mainControls)
                        , self._draw(oApp.oGroupDrawingArea.screen, self.__protected.screenControls)
                    ]

                    Promise.all(promises).then(() => {
                        resolve();
                    })
                    .catch(reason => {
                        reject(reason);
                    });
                })
                .catch(reason => {
                    reject(reason);
                });
        });
    }

    async draw(context) {
        this.__protected.backControls.forEach(ctrl => {
            ctrl(context);
        });

        this.__protected.mainControls.forEach(ctrl => {
            ctrl(context);
        });

        this.__protected.screenControls.forEach(ctrl => {
            ctrl(context);
        });
    }

    async _draw(drawingArea, controls) {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                try {
                    const context = drawingArea.getContext();

                    drawingArea.clean();

                    controls.forEach(ctrl => {
                        ctrl(context);
                    });

                    resolve();
                }
                catch (e) {
                    reject(e);
                }
            }, 0);
        });
    }
}