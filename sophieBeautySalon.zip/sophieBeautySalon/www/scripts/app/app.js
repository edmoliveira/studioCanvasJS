﻿(() => {
    "use strict";

    const sophieBsSoundKey = 'sophieBsSound';
    const sophieBsMusicKey = 'sophieBsMusic';

    let self = new Object();
    let hide = new Object();
    let oLoadingGame = null;

    (function () {
        let _isDeviceReady = false;
        let _util = new utilGame(self);
        let _groupDA = null;
        let _imageList = new LoadingImages();
        let _scene = null;

        Object.defineProperty(self, "oUtil", {
            get: function () {
                return _util;
            }
        });

        Object.defineProperty(self, "isDeviceReady", {
            get: function () {
                return _isDeviceReady;
            }
        });

        Object.defineProperty(self, "oGroupDrawingArea", {
            get: function () {
                return _groupDA;
            }
        });

        Object.defineProperty(self, "imageList", {
            get: function () {
                return _imageList;
            }
        });

        Object.defineProperty(self, "oScene", {
            get: function () {
                return _scene;
            }
        });

        self.setDeviceReady = function () {
            _isDeviceReady = true;
        }

        self.load = function (groupDA) {
            _groupDA = groupDA;
        }

        hide.loadScene = function () {
            _scene = createScene();
        }
    })();

    Object.defineProperty(self, "soundOn", {
        get: function () {
            var soundOnStorage = localStorage.getItem(sophieBsSoundKey);

            return soundOnStorage == null || soundOnStorage === 'true';
        }
        , set: function (v) {
            localStorage.setItem(sophieBsSoundKey, v === true ? 'true' : 'false');
        }
    });

    Object.defineProperty(self, "musicOn", {
        get: function () {
            var musicOnStorage = localStorage.getItem(sophieBsMusicKey);

            return musicOnStorage == null || musicOnStorage === 'true';
        }
        , set: function (v) {
            localStorage.setItem(sophieBsMusicKey, v === true ? 'true' : 'false');
        }
    });

    $(document).ready(function () {
        oLoadingGame = new loadingGame(self.oGroupDrawingArea.background);

        window_Resize();

        oLoadingGame.refresh();

        loadingScreen(function () {
            oLoadingGame.kill();
            oLoadingGame = null;

            hide.loadScene();
            self.oScene.start();
        });
    })

    $(window).resize(function () {
        window_Resize();

        if (oLoadingGame != null) {
            oLoadingGame.refresh();
        }

        if (self.oScene != null) {
            self.oScene.refresh();
        }
    })

    function window_Resize() {
        let screen = self.oUtil.getwindowSize();

        self.oGroupDrawingArea.resize(screen.width, screen.height);
    }

    function loadingScreen(fn) {
        //_bonusSound = new Audio('sounds/bonus.mp3');

         //_bonusSound.oncanplay = function () {
        //    this.wasLoading = true;
        //}

        let loadArray = [];

        let font = new Image();
        font.onerror = source => source.currentTarget.wasLoading = true;
        font.src = 'css/fonts/viper-squadron.solid.ttf';
        loadArray.push(font);

        font = new Image();
        font.onerror = source => source.currentTarget.wasLoading = true;
        font.src = 'css/fonts/WickedSeventies.ttf';
        loadArray.push(font);

        loadArray.push(self.imageList.loadHome());
        loadArray.push(self.imageList.loadMusicHome());
        loadArray.push(self.imageList.loadSoundHome());

        loadArray.push(self.imageList.loadCharacter());
        loadArray.push(self.imageList.loadHeadCharacter());
        loadArray.push(self.imageList.loadHairCharacter());
        loadArray.push(self.imageList.loadEarCharacter());
        loadArray.push(self.imageList.loadEyeCharacter());
        loadArray.push(self.imageList.loadMouthCharacter());

        loadExterns();

        function loadExterns() {
            let isOk = true;


            if (!self.isDeviceReady) {
                isOk = false;
            }
            else {
                for (let index = 0; index < loadArray.length; index++) {
                    if (!loadArray[index].wasLoading) {
                        isOk = false;
                        break;
                    }
                }
            }
            
            if (isOk) {
                fn();
            }
            else {
                setTimeout(loadExterns, 50);
            }
        }
    }

    Object.freeze(self);

    Object.defineProperty(window, 'oApp', {
        get: function () {
            return self;
        }
    });
})();