const createScene = (() => {
    "use strict";

    let animationId;
    let oTimer;

    let currentPage;
    let nextPage;

    let homePage;
    let characterPage;

    let wasBlocked = false;

    let touchStartEvents = [];
    let touchMoveEvents = [];
    let touchEndEvents = [];

    let touchStartOn = false;

    let actionNavegation = false;

    let wallpaperRect = null;

    let screenSize = oApp.oGroupDrawingArea.size;

    class Scene {
        constructor() {
            oTimer = oApp.oUtil.createTimer();

            homePage = new HomePage();
            homePage.x = 0;
            homePage.y = 0;

            characterPage = new CharacterPage();
            characterPage.x = 0;
            characterPage.y = 0;

            nextPage = null;

            this.oNavegation = new Navegation();
            this.oVelocity = new Velocity();

            wallpaperRect = new RectangleComponent();

            wallpaperRect.fillStyle = createStyleModel(typeFillStyle.LINEAR);

            wallpaperRect.fillStyle.addColorStop(0, '#ffc0cb');
            wallpaperRect.fillStyle.addColorStop(0.5, '#ad87c1');
            wallpaperRect.fillStyle.addColorStop(0.7, '#ad87c1');
            wallpaperRect.fillStyle.addColorStop(1, '#00bcd4');
        }

        start() {
            oTimer.begin();

            currentPage = characterPage;
            currentPage.isOpen = true;

            this.refresh();
        }

        refresh() {
            refreshArea();
        }

        onTouchStart(fn) {
            touchStartEvents.push(fn);
        }

        onTouchMove(fn) {
            touchMoveEvents.push(fn);
        }

        onTouchEnd(fn) {
            touchEndEvents.push(fn);
        }
    }

    class Velocity {
        constructor() {

        }

        get pageAnimationW() {
            return oApp.oUtil.getValueScale(500);
        }

        get pageAnimationH() {
            return oApp.oUtil.getValueScale(900);
        }
    }

    class Navegation {
        constructor() {

        }

        homeToCharacter() {
            currentPage.isOpen = false;

            nextPage = characterPage; 
            nextPage.width = 0;
            nextPage.height = 0;
            nextPage.y = screenSize.height / 2 - nextPage.height / 2;
            nextPage.x = screenSize.width / 2 - nextPage.width / 2;

            actionNavegation = true;
        }
    }

    function animationFrame() {
        wasBlocked = true;

        oTimer.current();

        currentPage.animation(oTimer)
            .then(() => {
                oTimer.end();

                wasBlocked = false;

                if (!actionNavegation) {
                    animationId = requestAnimationFrame(animationFrame);
                }
                else {
                    actionNavegation = false;
                    animationFrameNavegation();
                }
            })
            .catch(reason => {
                console.error(reason);

                wasBlocked = false;
            });
    }

    function animationFrameNavegation() {
        let canExit = false;

        wasBlocked = true;

        oTimer.current();

        const speedW = oTimer.getValuePosition(oApp.oScene.oVelocity.pageAnimationW);
        const speedH = oTimer.getValuePosition(oApp.oScene.oVelocity.pageAnimationH);

        currentPage.width -= speedW;
        currentPage.height -= speedH;

        nextPage.width += speedW;
        nextPage.height += speedH;

        if (currentPage.width < 0) { currentPage.width = 0; }
        if (currentPage.height < 0) { currentPage.height = 0; }

        if (nextPage.width > screenSize.width) { nextPage.width = screenSize.width; }
        if (nextPage.height > screenSize.height) { nextPage.height = screenSize.height; }

        const porcSizeC = currentPage.height / screenSize.height;
        const isGreaterThanHalf = porcSizeC >= 0.5;
        const porcC = isGreaterThanHalf ? porcSizeC - 0.5 : 0.5 - porcSizeC;

        const porcSizeN = nextPage.height / screenSize.height;
        const porcN = porcSizeN < 0.5 ? porcSizeN + 0.5 : 1 - (porcSizeN - 0.5);

        currentPage.y = screenSize.height / 2 - currentPage.height / 2;
        currentPage.x = (screenSize.width * porcC) - currentPage.width / 2;

        nextPage.y = screenSize.height / 2 - nextPage.height / 2;
        nextPage.x = (screenSize.width * porcN) - nextPage.width / 2;

        if (currentPage.width === 0
            && currentPage.height === 0
            && nextPage.width === screenSize.width
            && nextPage.height === screenSize.height) {
            canExit = true;
        }

        const backgroundDA = oApp.oGroupDrawingArea.background;
        const mainDA = oApp.oGroupDrawingArea.main;
        const screenDA = oApp.oGroupDrawingArea.screen;

        backgroundDA.clean();
        mainDA.clean();
        screenDA.clean();

        const context = backgroundDA.getContext();

        const backPage = isGreaterThanHalf ? nextPage : currentPage;
        const frontPage = isGreaterThanHalf ? currentPage : nextPage;

        backPage.draw(context);
        frontPage.draw(context);

        oTimer.end();

        wasBlocked = false;

        if (!canExit) {
            animationId = requestAnimationFrame(animationFrameNavegation);
        }
        else {
            currentPage = nextPage;
            currentPage.isOpen = true;

            nextPage = null;

            animationId = requestAnimationFrame(animationFrame);
        }
    }

    function resize() {
        const width = screenSize.width;
        const height = screenSize.height;

        currentPage.resize(width, height);
    }

    function initialize() {
        homePage.initialize();
        characterPage.initialize();
    }

    function refreshArea() {
        if (!wasBlocked) {
            resize();
            initialize();

            if (animationId != null) {
                cancelAnimationFrame(animationId);
            }

            const context = oApp.oGroupDrawingArea.wallpaper.getContext();

            oApp.oGroupDrawingArea.wallpaper.clean();

            //const context = oApp.oGroupDrawingArea.background.getContext();
            //oApp.oGroupDrawingArea.background.clean();

            //const area = screenSize.width * 2 + screenSize.height * 2;

            //let head = new ThreeHeadComponent(false);

            //head.firstColor = '#ffd0aa';
            //head.secondColor = '#fcc496';

            //head.width = area * 0.09;
            //head.height = head.width * 1.4;
            //head.x = screenSize.width / 2 - head.width / 2;
            //head.y = screenSize.height / 2 - head.height / 2;

            //let ear = new FourEarComponent(false);

            //ear.fillStyle.color = '#fcc496';
            //ear.setLocationSize(head);

            //let hair = new FourHairComponent(false);

            //hair.color1 = '#4c2a0e';
            //hair.color2 = '#572e0e';
            //hair.color3 = '#84542c';

            //hair.width = head.width * 0.88;
            //hair.height = head.height * 0.5;
            //hair.x = head.x + head.width / 2 - hair.width / 2;
            //hair.y = head.y - hair.height * 0.3;

            //const frontHair = hair.front;

            //frontHair.width = head.width * 0.77;
            //frontHair.height = head.height * 0.3;
            //frontHair.x = head.x + head.width / 2 - frontHair.width / 2;
            //frontHair.y = head.y;

            //let eye = new FourEyeComponent(false);

            //eye.eyeballColor = '#fbf3ec';
            //eye.lineEyeballColor = '#493C31';
            //eye.eyebrowColor = '#4c2a0e';
            //eye.irisColor = 'green';
            //eye.pupilColor = 'black';

            //eye.setLocationSize(head);

            //hair.render(context, () => {
            //    ear.render(context);
            //    head.render(context);
            //    eye.render(context);
            //});



            wallpaperRect.x = 0;
            wallpaperRect.y = 0;
            wallpaperRect.width = screenSize.width;
            wallpaperRect.height = screenSize.height;

            const wallLoc = wallpaperRect.location();

            wallpaperRect.fillStyle.setCoordinates(wallLoc.x1, wallLoc.y2, wallLoc.x2, wallLoc.y1);
            wallpaperRect.renderPath(context);

            animationFrame();
        }
        else {
            setTimeout(refreshArea, 50);
        }
    }
    
    $(oApp.oGroupDrawingArea.screen.element).on('touchstart mousedown', function (e) {
        e.preventDefault();

        touchStartOn = true;

        var offsetX = e.originalEvent.touches ? e.originalEvent.touches[0].pageX : e.originalEvent.pageX;
        var offsetY = e.originalEvent.touches ? e.originalEvent.touches[0].pageY : e.originalEvent.pageY;

        for (let index = touchStartEvents.length - 1; index >= 0; index--) {
            const fn = touchStartEvents[index];

            if (fn != null) {
                fn(offsetX, offsetY);
            }
            else {
                touchStartEvents.splice(index, 1);
            }
        }
    });

    $(oApp.oGroupDrawingArea.screen.element).on('touchmove mousemove', function (e) {
        e.preventDefault();

        var offsetX = e.originalEvent.touches ? e.originalEvent.touches[0].pageX : e.originalEvent.pageX;
        var offsetY = e.originalEvent.touches ? e.originalEvent.touches[0].pageY : e.originalEvent.pageY;

        for (let index = touchMoveEvents.length - 1; index >= 0; index--) {
            const fn = touchMoveEvents[index];

            if (fn != null) {
                fn(offsetX, offsetY);
            }
            else {
                touchMoveEvents.splice(index, 1);
            }
        }
    });

    $(oApp.oGroupDrawingArea.screen.element).on('touchend mouseup', eventCancel);
    $(oApp.oGroupDrawingArea.screen.element).on('touchcancel', eventCancel);
    $(window).on('touchend mouseup', eventCancel);

    function eventCancel(e) {
        if (touchStartOn) {
            touchStartOn = false;
            
            e.preventDefault();

            var offsetX = e.originalEvent.changedTouches ? e.originalEvent.changedTouches[0].pageX : e.originalEvent.pageX;
            var offsetY = e.originalEvent.changedTouches ? e.originalEvent.changedTouches[0].pageY : e.originalEvent.pageY;

            for (let index = touchEndEvents.length - 1; index >= 0; index--) {
                const fn = touchEndEvents[index];

                if (fn != null) {
                    fn(offsetX, offsetY);
                }
                else {
                    touchEndEvents.splice(index, 1);
                }
            }
        }
    }

    let obj = new Scene();

    Object.freeze(obj);

    return obj;
});